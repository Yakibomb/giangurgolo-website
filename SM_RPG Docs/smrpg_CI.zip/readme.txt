-included in archive are two savestates in ZSNES and snes9x format and a saveram
-put them in the same folder as the ROM, or whatever configured save directory
-the savestates and saveram file include only the special new items in the inventory

==The new items==
Shock Bomb	- Hit all enemies w/elec.shock
HermeticBalm	- Tightly sealed herbal essence

==The new equipment==
Relay Flag	- Outpace the enemy both in and out of battle!
Rubber Shoes	- Easy Super/Ultra Jumping
Kuribo'sShoe	- Reach high altitudes
Pyro Gloves	- Fireball Enhancement
Cement Cap	- Heavy stone cap turns wearer into a statue