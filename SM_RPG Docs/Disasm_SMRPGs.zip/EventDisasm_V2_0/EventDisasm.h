
#if !defined(AFX_EVENTDISASM_H__31207F08_C07B_11D3_BC2A_00E029364BE2__INCLUDED_)
#define AFX_EVENTDISASM_H__31207F08_C07B_11D3_BC2A_00E029364BE2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

#define TAG_END		(0)

CString FixedTextToCString(BYTE* pText, int nLength, DWORD tag, DWORD value, ... );

#define TTCS_BASE					(0x81000000)
#define TTCS_TrimTrailingSpaces		(TTCS_BASE + 1)

class Item
{
public:
	BYTE name[13];
};

class Esper
{
public:
	BYTE name[8];
};

class Character
{
public:
	BYTE name[6];
};

class DialogueItem
{
public:
	DialogueItem();
	~DialogueItem();

	int length;
	BYTE* text;
	
	void ConvertToASCII(CString& str, DWORD tag, DWORD value, ... );
};

// DialogueItem::ConvertToASCII tags
#define DI_Base					(0x83000000)
#define DI_ConvertMode			(DI_Base + 1)
#define DI_Offset				(DI_Base + 2)

// DI_ConvertMode
#define DICM_List				0x00000001
#define DICM_Edit				0x00000002

// DialogueItem::ConvertFromASCII errors
#define DICERROR_Malformed		-1


#endif // !defined(AFX_EVENTDISASM_H__31207F08_C07B_11D3_BC2A_00E029364BE2__INCLUDED_)
