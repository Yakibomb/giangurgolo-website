// EventDisasm.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "EventDisasm.h"
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

#define HEXSCRIPT_FN	_T("EventScriptHex.txt")
#define TXTSCRIPT_FN	_T("EventScriptTxt.txt")

#define SCRIPT_START	0x1E0000
#define SCRIPT_END		0x20E000

CWinApp theApp;
CTypedPtrArray<CPtrArray, DialogueItem*> dialogue;
Item items[256];
Esper espers[27];
Character characters[64];

CString g_strColorComponents[] =
{
	"None", "None",
	"Red", "Red",
	"Green", "Green",
	"Yellow [Red + Green]", "Yellow [Red + Green]",
	"Blue", "Blue",
	"Magenta [Red + Blue]", "Magenta [Red + Blue]",
	"Cyan [Green + Blue]", "Cyan [Green + Blue]",
	"White [Red + Green + Blue]", "White [Red + Green + Blue]",
};

void realMain(int iTextMode, CString iFf6Fn);
void readDialogue(CFile* m_pFile);
int serialise_script(CString iScriptFn, CString iFf6Fn);
BYTE ascii2nibble(BYTE iAsciiChar);



int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		BOOL lDoTextDecode = FALSE;
		BOOL lDoHexDecode = FALSE;
		BOOL lDoHexEncode = FALSE;
		BOOL lDoGetHelp = FALSE;
		CString lTmpStr;
		CString lRomFn, lScriptFn;

		printf(_T("EventDisasm Version for SMRPG\n\n"));
		printf(_T("Original findings & code by Yousei, Jan. 2000\n"));
		printf(_T("Modified by Lord J, March 2005\n"));
		printf(_T("Modified by giangurgolo, January 2007\n\n"));

		if(argc<3)
			lDoGetHelp = TRUE;
		else
		{
			if( !strcmp(argv[1], _T("/dt")) || !strcmp(argv[1], _T("-dt")) )
				lDoTextDecode = TRUE;
			else if( !strcmp(argv[1], _T("/dh")) || !strcmp(argv[1], _T("-dh")) )
				lDoHexDecode = TRUE;
			else if( !strcmp(argv[1], _T("/eh")) || !strcmp(argv[1], _T("-eh")) )
				lDoHexEncode = TRUE;
			else
				lDoGetHelp = TRUE;

			lRomFn = argv[2];

			if(lDoHexEncode && (argc<4))
				lDoGetHelp = TRUE;
			else if(lDoHexEncode)
				lScriptFn = argv[3];
		}

		if(lDoGetHelp)
		{
			printf(_T("Usage\n"));
			printf(_T("/# = bank number to decode (/1 = bank 1E, /2 = bank 1F, /3 = bank 20"));
			printf(_T("EventDisasm /dt <SMRPG image> /#: decode game script in text mode\n"));
			printf(_T("EventDisasm /eh <SMRPG image> /# <hex script> : encode game script in hex mode\n"));
			printf(_T("EventDisasm /? : this help message\n\n"));
		}
		else
		{
			if(lDoTextDecode)
			{
				printf(_T("Exporting %s's script to text file...\n"), lRomFn);
			}
			else // if(lDoHexEncode)
			{
				printf(_T("Merging %s hex script with %s...\n"), lScriptFn, lRomFn);
			}

			if(lDoTextDecode || lDoHexDecode)
			{
				realMain(lDoTextDecode, lRomFn);
				for(int i = 0; i < dialogue.GetSize(); i++)
					delete dialogue[i];
				dialogue.RemoveAll();
			}
			else if(lDoHexEncode)
				serialise_script(lScriptFn, lRomFn);
		}
	}

	return nRetCode;
}


void realMain(int iTextMode, CString iFf6Fn)
{
	CFile file;

	if(file.Open(iFf6Fn, CFile::modeRead) == NULL)
	{
		printf(_T("Errors reading %s\n"), iFf6Fn);
		return;
	}

	ofstream outFile;
	CString lScriptFn = iTextMode?TXTSCRIPT_FN:HEXSCRIPT_FN;
	outFile.open(lScriptFn);
	if(outFile == NULL)
	{
		printf(_T("Errors creating %s\n"), lScriptFn);
		return;
	}

	readDialogue(&file);

	DWORD dwOffset = 0;
	DWORD dwBank = 0;
	DWORD pOffset = 0x1E0002;
	DWORD nextEvent = 0;
	DWORD pc;
	DWORD dwQueueStart = 0;
	BYTE bQueueLen = 0;
	WORD eCounter = 0;

	CString t;
	BYTE b[16];
	WORD w[16];
	DWORD d[16];
	CString s[16];
	BOOL bFirst;
	int nChoices = 0;
	int x, y;
	int lEnTxt = 0;
	int lEnBytes = 1;
	int lBakPtr;

	file.Seek(SCRIPT_START, CFile::begin);
	// end at 0x0CE800

	lEnTxt = iTextMode?1:0;
	lEnBytes = iTextMode?0:1;

	dwOffset = dwBank = file.GetPosition();

	while(dwOffset < SCRIPT_END)
	{
		t.Format("EVENT [%03X] ------------------------------------------------------------>", eCounter); outFile << t << endl;

		if(dwOffset == 0x1E0000) dwOffset = 0x1E0C00;

		file.Seek(pOffset, CFile::begin);
		file.Read(w, 2);

		dwBank = dwOffset & 0xFF0000;
		nextEvent = dwBank + w[0];

		pOffset = file.GetPosition();

		if(pOffset == 0x1E0C02 || dwOffset == 0x1F0000)
		{
			pOffset = 0x1F0002;
			dwOffset = 0x1F0C00;
		}
		else if(pOffset == 0x1F0C02 || dwOffset == 0x200000)
		{
			pOffset = 0x200002;
			dwOffset = 0x200800;
		}
		else if(pOffset == 0x200802 || dwOffset == 0x20E000) return;

		eCounter++;

		file.Seek(dwOffset, CFile::begin);

		while(dwOffset < nextEvent && dwOffset < SCRIPT_END)
		{
			for(int i = 0; i < 16; i++)
			{
				b[i] = w[i] = d[i] = 0;
				s[i].Empty();
			}

			bFirst = TRUE;

			pc = dwOffset + 0xC00000;

			dwQueueStart = 0;
			bQueueLen = 0;

			// Read the opcode.
			BYTE opcode = 1;
			BYTE param = 1;

				file.Read(&opcode, 1);

				if(lEnBytes)
				{
					t.Format("%02X/%04X: %02X", (pc & 0xFF0000) >> 16, pc & 0xFFFF, opcode);
				}
				else
				{
					t.Format("%02X/%04X: %02X ", (pc & 0xFF0000) >> 16, pc & 0xFFFF, opcode);
				}
				outFile << t;

				switch(opcode)
				{
				case 0x32:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("<UNKNOWN COMMAND $32>");outFile << t;break;

				case 0x33:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("<UNKNOWN COMMAND $32>");outFile << t;break;

				case 0x34:
					file.Read(b, 1);

					if(b[0] & 0x01)	s[0] = "left ";
					if(b[0] & 0x02)	s[1] = "right ";
					if(b[0] & 0x04)	s[2] = "down ";
					if(b[0] & 0x08)	s[3] = "up ";
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Change directional maneuverability: %s%s%s%s", s[0], s[1], s[2], s[3]);outFile << t;break;

				case 0x35:
					file.Read(b, 1);

					if(b[0] & 80) s[0] = "Enable";
					else s[0] = "Disable";
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("%s Overworld Menu", s[0]);outFile << t;break;

				case 0x36:
					file.Read(b, 1);

					switch(b[0] & 0x0F)
					{
					case 0: s[0] = "MARIO";break;
					case 1: s[0] = "TOADSTOOL";break;
					case 2: s[0] = "BOWSER";break;
					case 3: s[0] = "GENO";break;
					case 4: s[0] = "MALLOW";break;
					default: s[0] = "<INVALID>";break;
					}

					if(b[0] & 0x80)	s[1] = " (also increase maximum number of party members by 1)";
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Add %s to party%s", s[0], s[1]);outFile << t;break;

				case 0x37: outFile << "                  Store total number of characters in party to 00:7000";break;

				case 0x38:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Store character in slot %d to 00:7000", b[0]);outFile << t;break;

				case 0x39:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("<UNKNOWN COMMAND: pointer to address $%02X%02X>", b[2], b[1]);outFile << t;break;

				case 0x3A:
					file.Read(b, 5);
					t.Format("%02X %02X %02X %02X %02X    ", b[0], b[1], b[2], b[3], b[4]);outFile << t;
					t.Format("<UNKNOWN COMMAND: pointer to address $%02X%02X or address $%02X%02X>", b[2], b[1], b[4], b[3]);outFile << t;break;

				case 0x3B:
					file.Read(b, 5);
					t.Format("%02X %02X %02X %02X %02X    ", b[0], b[1], b[2], b[3], b[4]);outFile << t;
					t.Format("<UNKNOWN COMMAND: pointer to address $%02X%02X or address $%02X%02X>", b[2], b[1], b[4], b[3]);outFile << t;break;

				case 0x3C:
					file.Read(b, 5);
					t.Format("%02X %02X %02X %02X %02X    ", b[0], b[1], b[2], b[3], b[4]);outFile << t;
					t.Format("<UNKNOWN COMMAND: pointer to address $%02X%02X>", b[4], b[3]);outFile << t;break;

				case 0x3D:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN COMMAND: pointer to address $%02X%02X>", b[1], b[0]);outFile << t;break;

				case 0x3E:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("<UNKNOWN COMMAND: pointer to address $%02X%02X>", b[3], b[2]);outFile << t;break;

				case 0x3F:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("<UNKNOWN COMMAND: pointer to address $%02X%02X>", b[2], b[1]);outFile << t;break;

				case 0x40:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Execute event id $%02X%02X simultaneously with the following commands", b[1], b[0]);outFile << t;break;

				case 0x41:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If value at 00:316D = 3, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0x42:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("<UNKNOWN COMMAND $%02X>", opcode);outFile << t;break;

				case 0x43: outFile << "                  <UNKNOWN COMMAND $43>";break;

				case 0x44:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN COMMAND $%02X>", opcode);outFile << t;break;

				case 0x45:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN COMMAND $%02X>", opcode);outFile << t;break;

				case 0x46:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("<UNKNOWN COMMAND $%02X>", opcode);outFile << t;break;

				case 0x47:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("<UNKNOWN COMMAND $%02X>", opcode);outFile << t;break;

				case 0x48: outFile << "                  Engage in battle?";break;

				case 0x49: outFile << "                  Engage in battle with formation pack from 00:700E";break;

				case 0x4A:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("Engage in battle with formation pack #$%02X%02X in background #$%02X", b[1], b[0], b[2]);outFile << t;break;

				case 0x4B:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Lead to World Map Point $%02X%02X", b[1], b[0]);outFile << t;break;

				case 0x4C:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Open Shop Menu $%02X", b[0]);outFile << t;break;

				case 0x4D: outFile << "                  <UNKNOWN COMMAND $4D>";break;

				case 0x4E:
					file.Read(b, 2);

					switch(b[1])
					{
					case 0x00: s[1] = "Toad teaches how to equip";s[2] = "MARIO falls toward pipe house";break;
					case 0x01: s[1] = "Toad teaches how to use items";s[2] = "MARIO returns to Mushroom Kingdom from Booster Tower";break;
					case 0x02: s[1] = "Toad teaches how to switch allies";s[2] = "MARIO takes the Nimbus bus to BOWSER's Keep";break;
					case 0x03: s[1] = "Toad teaches how to play beetle mania";break;
					default: s[1] = "<UNKNOWN>";s[2] = "<UNKNOWN>";break;
					}

					switch(b[0])
					{
					case 0x00: s[0] = "Open \"select game menu\"";break;
					case 0x01: s[0] = "Open overworld menu";break;
					case 0x02: s[0].Format("Open world map $%02X", b[1]);break;
					case 0x03: s[0].Format("Open shop menu $%02X", b[1]);break;
					case 0x04: s[0] = "Open \"save game\" menu";break;
					case 0x05: s[0].Format("Open \"Item maxed out\" menu, toss item $%02X", b[1]);break;
					case 0x07: s[0].Format("Menu tutorial: %s", s[1]);break;
					case 0x08: s[0].Format("Add star piece #%d to star collection", b[1]);break;
					case 0x09: s[0] = "Start Moleville Mountain ride";break;
					case 0x0B: s[0] = "INTRO - Moleville Mountain";break;
					case 0x0D: s[0].Format("ENDING - Star Piece Event #%d", b[1]);break;
					case 0x0E: s[0] = "TOADSTOOL in garden";break;
					case 0x0F: s[0] = "Party falling through Factory Gate";break;
					case 0x10: s[0].Format("World Map Event: %s", s[2]);break;
					default: s[0] = "<UNKNOWN>";break;
					}
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Run Event: %s", s[0]);outFile << t;break;

				case 0x4F:
					file.Read(b, 1);

					switch(b[0])
					{
					case 0x00: s[0] = "Choose Game";break;
					case 0x01: s[0] = "Overworld Menu";break;
					case 0x02: s[0] = "Return to World Map";break;
					case 0x03: s[0] = "Mushroom Kingdom Shop";break;
					case 0x04: s[0] = "Save Game";break;
					case 0x05: s[0] = "Items Maxed Out";break;
					default: s[0] = "<UNKNOWN>";break;
					}
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Open Menu: %s", s[0]);outFile << t;break;

				case 0x50:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Put item in inventory: #$%02X (%s)", b[0], FixedTextToCString(items[b[0]].name, 13, TAG_END, 0));outFile << t;break;

				case 0x51:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Remove item in inventory: #$%02X (%s)", b[0], FixedTextToCString(items[b[0]].name, 13, TAG_END, 0));outFile << t;break;

				case 0x52:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Add %d coins", b[0]);outFile << t;break;

				case 0x53:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Add %d frog coins", b[0]);outFile << t;break;

				case 0x54:
					file.Read(b, 2);

					switch(b[0])
					{
					case 0x00: s[0] = "MARIO";break;
					case 0x01: s[0] = "TOADSTOOL";break;
					case 0x02: s[0] = "BOWSER";break;
					case 0x03: s[0] = "GENO";break;
					case 0x04: s[0] = "MALLOW";break;
					default: s[0] = "<INVALID>";break;
					}
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Equip %s with item #$%02X (%s)", s[0], b[1], FixedTextToCString(items[b[1]].name, 13, TAG_END, 0));outFile << t;break;

				case 0x55: outFile << "                  Store total number of empty slots in item inventory to 00:7000";break;

				case 0x56:
					file.Read(b, 1);

					switch(b[0])
					{
					case 0x00: s[0] = "MARIO";break;
					case 0x01: s[0] = "TOADSTOOL";break;
					case 0x02: s[0] = "BOWSER";break;
					case 0x03: s[0] = "GENO";break;
					case 0x04: s[0] = "MALLOW";break;
					default: s[0] = "<INVALID>";break;
					}
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Reduce %s's HP by amount stored in 00:7000", s[0]);outFile << t;break;

				case 0x5C:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Immediately read from address $%02X%02X", b[1], b[0]);outFile << t;break;

				case 0x5D: outFile << "                  Load 00:600F";break;

				case 0x60:
					file.Read(w, 3);

					if((w[1] & 0x0080))
						s[0] = "Paragraph";
					else s[0] = "Single line";

					if((w[1] & 0x0040))
						s[1] = "Vellum paper";
					else s[1] = "Floating blue text";

					if((w[0] & 0x8000)) s[2] = " (Wait until complete)";
					t.Format("%02X %02X %02X          ", w[0]&0x00FF, w[0]>>8, w[1]&0x00FF);outFile << t;
					t.Format("Run Dialogue $%04X%s\n                              ", (w[0] & 0x1FFF), s[2]);outFile << t;
					t.Format("---> Box Style: %s\n                              ", s[0]);outFile << t;
					t.Format("---> Box BG: %s", s[1]);outFile << t;

					if((w[0] & 0x1FFF) < dialogue.GetSize())
					{
						dialogue[w[0] & 0x1FFF]->ConvertToASCII(t, DI_ConvertMode, DICM_List, TAG_END, 0);
						outFile << endl << endl << t << endl;

					}
					else
					{
						outFile << "               <Invalid Dialogue>";
						nChoices = 0;
					}
					break;

				case 0x61:
					file.Read(b, 2);

					switch(b[1] & 0x03)
					{
					case 1: s[0] = "middle of screen";break;
					case 2: s[0] = "bottom of screen";break;
					default: s[0] = "top of screen";break;
					}

					if((b[1] & 0x70) >= 0x00 && (b[1] & 0x70) <= 0x10) s[1] = "Single line of floating blue text";
					else if((b[1] & 0x70) >= 0x20 && (b[1] & 0x70) <= 0x30) s[1] = "Single line of normal text on vellum paper";
					else if((b[1] & 0x70) >= 0x40 && (b[1] & 0x70) <= 0x50) s[1] = "Paragraph of floating blue text";
					else if((b[1] & 0x70) >= 0x60 && (b[1] & 0x70) <= 0x70) s[1] = "Paragraph of normal text on vellum paper";
					else s[1] = "<UNKNOWN>";
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Run Dialogue from 00:7000\n                              ");outFile << t;
					t.Format("<UNKNOWN: $%02X>\n                              ", b[0]);outFile << t;
					t.Format("Position: %s\n                              ", s[0]);outFile << t;
					t.Format("Box Style: %s", s[1]);outFile << t;break;

				case 0x62:
					file.Read(w, 2);

					switch(0xE000 & w[0])
					{
					case 0x2000: s[0] = "short";break;
					case 0x4000: s[0] = "normal";break;
					default: s[0] = "forever";break;
					}

					if((w[0] & 0x8000)) s[1] = " (Wait until complete)";

					t.Format("%02X %02X             ", w[0] & 0x00FF, w[0]>>8);outFile << t;
					t.Format("Run Dialogue $%04X%s\n                              ", (w[0] & 0x1FFF), s[1]);outFile << t;
					t.Format("Duration: %s", s[0]);outFile << t;

					if((w[0] & 0x1FFF) < dialogue.GetSize())
					{
						dialogue[w[0] & 0x1FFF]->ConvertToASCII(t, DI_ConvertMode, DICM_List, TAG_END, 0);
						outFile << endl << endl << t << endl;

					}
					else
					{
						outFile << "               <Invalid Dialogue>";
						nChoices = 0;
					}
					break;

				case 0x66:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If 2nd option chosen from dialogue prompt, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0x67:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("If 2nd option chosen from dialogue prompt, jump to address $%02X/%02X%02X\n                              ", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;
					t.Format("If 3rd option chosen from dialogue prompt, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[3], b[2]);outFile << t;break;

				case 0x68:
					file.Read(b, 5);

					switch(b[4] & 0xE0)
					{
					case 0x00: s[0] = "right";break;
					case 0x20: s[0] = "down-right";break;
					case 0x40: s[0] = "down";break;
					case 0x60: s[0] = "down-left";break;
					case 0x80: s[0] = "left";break;
					case 0xA0: s[0] = "up-left";break;
					case 0xC0: s[0] = "up";break;
					case 0xE0: s[0] = "up-right";break;
					}
					t.Format("%02X %02X %02X %02X %02X    ", b[0], b[1], b[2], b[3], b[4]);outFile << t;
					t.Format("Enter area: $%02X%02X\n                              ", (0x01 & b[1]), b[0]);outFile << t;
					t.Format("MARIO will be at coords: (%d,%d) Z=%d\n                              ", (((b[2] & 0x7F) * 0x20) + (0x10 * (b[3] & 1))), ((b[3] & 0x7F) * 8), ((b[4] & 0x1F) * 0x10));outFile << t;
					t.Format("MARIO will face: %s\n                              ", s[0]);outFile << t;
					t.Format("<UNKNOWN=#$%02X>", (0xA8 & b[1]));outFile << t;break;

				case 0x6A:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Modify BGL of area $%02X%02X", b[1], b[0]);outFile << t;break;

				case 0x6B:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Modify physical field of area $%02X%02X", b[1], b[0]);outFile << t;break;

				case 0x70: outFile << "                  Simultaneously lighten screen from black with following commands";break;

				case 0x71: outFile << "                  Lighten screen from black before following commands";break;

				case 0x72:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Simultaneously lighten screen from black with following commands; Duration: %d frames", b[0]);outFile << t;break;

				case 0x73:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Lighten screen from black before following commands; Duration: %d frames", b[0]);outFile << t;break;

				case 0x74: outFile << "                  Simultaneously darken screen from normal with following commands";break;

				case 0x75: outFile << "                  Darken screen from normal before following commands";break;

				case 0x76:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Simultaneously darken screen from black with following commands; Duration: %d frames", b[0]);outFile << t;break;

				case 0x77:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Darken screen from black before following commands; Duration: %d frames", b[0]);outFile << t;break;

				case 0x8A:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Set %d palettes from $%06X", ((b[0] & 0xF0) / 0x10), ((b[1] * 0x20) + 0x37A000));outFile << t;break;

				case 0x91:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Play music: #$%02X", b[0]);outFile << t;break;

				case 0x92:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Fade in music: #$%02X", b[0]);outFile << t;break;

				case 0x93: outFile << "                  Fade out music";break;

				case 0x94: outFile << "                  Stop music";break;

				case 0x95:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Fade out music to volume %d; Duration: %d frames", b[1], b[0]);outFile << t;break;

				case 0x96:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN>", b[1], b[0]);outFile << t;break;

				case 0x97:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN>");outFile << t;break;

				case 0x98:
					file.Read(b, 2);

					if (b[1] & 0x80) s[0] = "Slow down";
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("%s music speed by %d frames", s[0], b[0]);outFile << t;break;

				case 0x9B: outFile << "                  Stop sound effect";break;

				case 0x9C:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Play sound effect #$%02X", b[0]);outFile << t;break;

				case 0x9D:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Play sound effect #$%02X; speaker balance: %d", b[0], b[1]);outFile << t;break;

				case 0x9E:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN>");outFile << t;break;

				case 0x9F:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN>");outFile << t;break;

				case 0xA0:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Set event flag memory address 00:%04X Bit %d", (((((opcode * 0x0100) + b[0]) - 0xA000) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

				case 0xA1:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Set event flag memory address 00:%04X Bit %d", (((((opcode * 0x0100) + b[0]) - 0xA000) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

				case 0xA2:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Set event flag memory address 00:%04X Bit %d", (((((opcode * 0x0100) + b[0]) - 0xA000) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

				case 0xA3: outFile << "                  Set memory address Bit using 00:7000";break;

				case 0xA4:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Clear event flag memory address 00:%04X Bit %d", (((((opcode * 0x0100) + b[0]) - 0xA400) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

				case 0xA5:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Clear event flag memory address 00:%04X Bit %d", (((((opcode * 0x0100) + b[0]) - 0xA400) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

				case 0xA6:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Clear event flag memory address 00:%04X Bit %d", (((((opcode * 0x0100) + b[0]) - 0xA400) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

				case 0xA7: outFile << "                  Clear memory address Bit using 00:7000";break;

				case 0xA8:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Store #$%02X to 00:%04X", b[1], (0x70A0 + b[0]));outFile << t;break;

				case 0xA9:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Add #$%02X to 00:%04X", b[1], (0x70A0 + b[0]));outFile << t;break;

				case 0xAA:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Increment 00:%04X", (b[0] + 0x70A0));outFile << t;break;

				case 0xAB:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Decrement 00:%04X", (b[0] + 0x70A0));outFile << t;break;

				case 0xAC:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Store #$%02X%02X to 00:7000", b[1], b[0]);outFile << t;break;

				case 0xAD:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Store #$%02X%02X to 00:7000", b[1], b[0]);outFile << t;break;

				case 0xAE: outFile << "                  Increment 00:7000";break;

				case 0xAF: outFile << "                  Decrement 00:7000";break;

				case 0xB0:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("Store #$%02X%02X to 00:%04X", b[2], b[1], (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xB1:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("Add #$%02X%02X to 00:%04X", b[2], b[1], (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xB2:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Increment 00:%04X", (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xB3:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Decrement 00:%04X", (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xB4:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Store value at 00:%04X to 00:7000", (0x70A0 + b[0]));outFile << t;break;

				case 0xB5:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Store value at 00:7000 to 00:%04X", (0x70A0 + b[0]));outFile << t;break;

				case 0xB6:
					file.Read(b, 2);
					t.Format("%02X %02X              ", b[0], b[1]);outFile << t;
					t.Format("Store a random number from 0 to #$%02X%02X to 00:7000", b[1], b[0]);outFile << t;break;

				case 0xB7:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("Store a random number from 0 to #$%02X%02X to 00:%04X", b[2], b[1], (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xB8:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Add value at 00:%04X to 00:7000", (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xB9:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Subtract value at 00:%04X to 00:7000", (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xBA:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Store value at 00:%04X to 00:7000", (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xBB:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Store value at 00:7000 to 00:%04X", (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xBC:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Store value at 00:%04X to 00:%04X", (0x7000 + (b[0] * 2)), (0x7000 + (b[1] * 2)));outFile << t;break;

				case 0xBD:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Exchange values at memory addresses 00:%04X and 00:%04X", (0x7000 + (b[0] * 2)), (0x7000 + (b[1] * 2)));outFile << t;break;

				case 0xBE: outFile << "                  Store values at addresses 00:7010,00:7012,00:7014 to 00:7016,00:7018,00:701A";break;

				case 0xBF: outFile << "                  Store values at addresses 00:7016,00:7018,00:701A to 00:7010,00:7012,00:7014";break;

				case 0xC0:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Compare value at 00:7000 to #$%02X%02X", b[1], b[0]);outFile << t;break;

				case 0xC1:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Compare values at memory addresses 00:%04X and 00:7000", (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xC2:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("Compare value at 00:%04X to #$%02X%02X", (0x7000 + (b[0] * 2)), b[2], b[1]);outFile << t;break;

				case 0xC4:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C4>";break;

				case 0xC5:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C5>";break;

				case 0xC6:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Store value at 00:%04X to 00:7000 and clear 00:7001", (0x6004 + (b[0] * 0x60)));outFile << t;break;

				case 0xC7:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C7>";break;

				case 0xC8:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C8>";break;

				case 0xC9:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C9>";break;

				case 0xCA: outFile << "                  Store held joypad register to 00:7000,00:7001";break;

				case 0xCB: outFile << "                  Store joypad register to 00:7000,00:7001";break;

				case 0xD0:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Execute event id $%02X%02X subsequently", b[1], b[0]);outFile << t;break;

				case 0xD1:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Execute event id $%02X%02X", b[1], b[0]);outFile << t;break;

				case 0xD2:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xD3:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xD4:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Start code block, repeat %d times", b[0]);outFile << t;break;

				case 0xD5:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN COMMAND $D5>");outFile << t;break;

				case 0xD6:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Store value at 00:%04X to object memory", (0x7000 + (b[0] * 2)));outFile << t;break;

				case 0xD7: outFile << "                  End of code block";break;

				case 0xD8:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("If event flag memory address 00:%04X Bit %d set, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xD800) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

				case 0xD9:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("If event flag memory address 00:%04X Bit %d set, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xD800) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

				case 0xDA:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("If event flag memory address 00:%04X Bit %d set, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xD800) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

				case 0xDB:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If Bit set at memory address (set by value at 00:7000), jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xDC:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("If event flag memory address 00:%04X Bit %d clear, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xDC00) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

				case 0xDD:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("If event flag memory address 00:%04X Bit %d clear, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xDC00) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

				case 0xDE:
					file.Read(b, 3);
					t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
					t.Format("If event flag memory address 00:%04X Bit %d clear, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xDC00) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

				case 0xDF:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If Bit clear at memory address (set using value at 00:7000), jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xE0:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("If value at 00:%04X = #$%02X, jump to address $%02X/%02X%02X", (b[0] + 0x70A0), b[1], (pc & 0xFF0000) >> 16, b[3], b[2]);outFile << t;break;

				case 0xE1:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("If value at 00:%04X != #$%02X, jump to address $%02X/%02X%02X", (b[0] + 0x70A0), b[1], (pc & 0xFF0000) >> 16, b[3], b[2]);outFile << t;break;

				case 0xE2:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("If value at 00:7000 = #$%02X%02X, jump to address $%02X/%02X%02X", b[1], b[0], (pc & 0xFF0000) >> 16, b[3], b[2]);outFile << t;break;

				case 0xE3:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("If value at 00:7000 != #$%02X%02X, jump to address $%02X/%02X%02X", b[1], b[0], (pc & 0xFF0000) >> 16, b[3], b[2]);outFile << t;break;

				case 0xE4:
					file.Read(b, 5);
					t.Format("%02X %02X %02X %02X %02X    ", b[0], b[1], b[2], b[3], b[4]);outFile << t;
					t.Format("If value at 00:%04X = #$%02X%02X, jump to address $%02X/%02X%02X", ((b[0] * 2) + 0x7000), b[2], b[1], (pc & 0xFF0000) >> 16, b[4], b[3]);outFile << t;break;

				case 0xE5:
					file.Read(b, 5);
					t.Format("%02X %02X %02X %02X %02X    ", b[0], b[1], b[2], b[3], b[4]);outFile << t;
					t.Format("If value at 00:%04X = #$%02X%02X, jump to address $%02X/%02X%02X", ((b[0] * 2) + 0x7000), b[2], b[1], (pc & 0xFF0000) >> 16, b[4], b[3]);outFile << t;break;

				case 0xE6:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("If memory address 00:7000 Bit $%02X%02X set, do NOT jump to address $%02X/%02X%02X", b[1], b[0], (pc & 0xFF0000) >> 16, b[3], b[2]);outFile << t;break;

				case 0xE7:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("If memory address 00:7000 Bit $%02X%02X set, jump to address $%02X/%02X%02X", b[1], b[0], (pc & 0xFF0000) >> 16, b[3], b[2]);outFile << t;break;

				case 0xE8:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If random number between 0 and 255 > 128, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xE9:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If random number between 0 and 255 > 66, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xEA:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If Bit 1 of 00:70A0,x set, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xEB:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If Bit 1 of 00:70A0,x clear, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xEC:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If Bit 0 of 00:70A0,x set, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xED:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If Bit 0 of 00:70A0,x clear, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xEE:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If Bit 7 of 00:70A0,x clear, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xEF:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("If Bit 7 of 00:70A0,x set, jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

				case 0xF0:
					file.Read(b, 1);
					t.Format("%02X                ", b[0]);outFile << t;
					t.Format("Duration: %u frames", b[0]);outFile << t;break;

				case 0xF1:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("Duration: %u frames", ((b[1] * 0x100) + b[0]));outFile << t;break;

				case 0xF2:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN COMMAND $F2>");outFile << t;break;

				case 0xF3:
					file.Read(b, 2);
					t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
					t.Format("<UNKNOWN COMMAND $F2>");outFile << t;break;

				case 0xF5: outFile << "                  <UNKNOWN COMMAND: check current area?>";break;

				case 0xF6: outFile << "                  <UNKNOWN COMMAND: check current area?>";break;

				case 0xF7: outFile << "                  <UNKNOWN COMMAND: check object maps?>";break;

				case 0xF8:
					file.Read(b, 4);
					t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]);outFile << t;
					t.Format("<UNKNOWN COMMAND $F8>");outFile << t;break;

				case 0xF9: outFile << "                  Restart event from beginning";break;

				case 0xFA: outFile << "                  Restart event from beginning";break;

				case 0xFB: outFile << "                  Reset game, choose game" << endl;break;

				case 0xFC: outFile << "                  Reset game" << endl;break;

				case 0xFE: outFile << "                  Return" << endl;break;

				case 0xFF: outFile << "                  Return all" << endl;break;

				case 0xFD:
					file.Read(b, 1);
					param = b[0];
					t.Format("%02X ", param);
					outFile << t;

					switch(param)
					{

					case 0x30: outFile << "               Screen moves with MARIO";break;

					case 0x31: outFile << "               Screen doesn't move with MARIO";break;

					case 0x33:
						file.Read(b, 3);
						t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t;
						t.Format("If Bit 5 of 00:%04X set, jump to address $%02X/%02X%02X", ((b[0] * 0x60) + 0x6006), (pc & 0xFF0000) >> 16, b[2], b[1]); outFile << t;break;

					case 0x34:
						file.Read(b, 3);
						t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t;
						t.Format("If Bit 4,5 of 00:%04X set, jump to address $%02X/%02X%02X", ((b[0] * 0x60) + 0x600C), (pc & 0xFF0000) >> 16, b[2], b[1]); outFile << t;break;

					case 0x3D:
						file.Read(b, 3);
						t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t;
						t.Format("If Bit 6 of 00:%04X set, jump to address $%02X/%02X%02X", ((b[0] * 0x60) + 0x6006), (pc & 0xFF0000) >> 16, b[2], b[1]); outFile << t;break;

					case 0x3E:
						file.Read(b, 5);
						t.Format("%02X %02X %02X %02X %02X ", b[0], b[1], b[2], b[3], b[4]); outFile << t;
						t.Format("<UNKNOWN COMMAND: pointer to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[4], b[3]); outFile << t;break;

					case 0x3F:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("<UNKNOWN COMMAND: pointer to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]); outFile << t;break;

					case 0x46:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("<UNKNOWN COMMAND $46>"); outFile << t;break;

					case 0x48: outFile << "               Store #$00 to 00:3174 and 00:3114";break;

					case 0x49: outFile << "               Store #$01 to 00:3114";break;

					case 0x4A: outFile << "               Save Game";break;

					case 0x4C:
						file.Read(b, 1);
						switch(b[0])
						{
						case 0x00: s[0] = "Toad teaches how to equip";break;
						case 0x01: s[0] = "Toad teaches how to use items";break;
						case 0x02: s[0] = "Toad teaches how to switch allies";break;
						case 0x03: s[0] = "Toad teaches how to play beetle mania";break;
						default: s[0] = "<UNKNOWN>";break;
						}
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Run Toad's tutorial: %s", s[0]); outFile << t;break;

					case 0x4D:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("ENDING - Star Piece Scene #%d", b[0]); outFile << t;break;

					case 0x4E: outFile << "               Start Moleville Mountain Game";break;

					case 0x4F: outFile << "               INTRO - Moleville Mountain";break;

					case 0x50: outFile << "               Store item to item inventory from 00:70A7";break;

					case 0x51: outFile << "               Store item to equipment inventory from 00:70A7";break;

					case 0x52: outFile << "               Add # at 00:7000 to total coins";break;

					case 0x53: outFile << "               Subtract # at 00:7000 from total coins";break;

					case 0x54: outFile << "               Add # at 00:7000 to total frog coins";break;

					case 0x55: outFile << "               Subtract # at 00:7000 from total frog coins";break;

					case 0x56: outFile << "               Add # at 00:7000 to current FP";break;

					case 0x57: outFile << "               Add # at 00:7000 to max FP";break;

					case 0x58:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Store the number of instances in item inventory of item #$%02X (%s) to 00:7000", b[0], FixedTextToCString(items[b[0]].name, 13, TAG_END, 0)); outFile << t;break;

					case 0x59: outFile << "               Store # of current coins to 00:7000";break;

					case 0x5A: outFile << "               Store # of current frog coins to 00:7000";break;

					case 0x5B: outFile << "               Restore all HP";break;

					case 0x5C: outFile << "               Restore all FP";break;

					case 0x5D:
						file.Read(b, 2);
						switch(b[0])
						{
						case 0x00: s[0] = "MARIO";break;
						case 0x01: s[0] = "TOADSTOOL";break;
						case 0x02: s[0] = "BOWSER";break;
						case 0x03: s[0] = "GENO";break;
						case 0x04: s[0] = "MALLOW";break;
						default: s[0] = "<INVALID CHARACTER>";break;
						}
						switch(b[1])
						{
						case 0x00: s[1] = "WEAPON";break;
						case 0x01: s[1] = "ARMOR";break;
						case 0x02: s[1] = "ACCESSORY";break;
						default: s[1] = "<INVALID ITEM>";break;
						}
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("Store %s's equipped %s to 00:7000", s[0], s[1]); outFile << t;break;

					case 0x5E: outFile << "               Store value at 00:70A7 to 00:7000";break;

					case 0x62:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("If memory address 00:0210 Bits 0,1,2 clear, do NOT jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]); outFile << t;break;

					case 0x64: outFile << "               Add XP received from battle to current XP";break;

					case 0x65: outFile << "               Open Level Up Bonus menu";break;

					case 0x66:
						file.Read(b, 2);
						switch(b[1])
						{
						case 0x00: s[0] = "MARIO";break;
						case 0x01: s[0] = "TOADSTOOL";break;
						case 0x02: s[0] = "BOWSER";break;
						case 0x03: s[0] = "GENO";break;
						case 0x04: s[0] = "MALLOW";break;
						case 0X05: s[0] = "IN...";break;
						default: s[0] = "<INVALID>";break;
						}
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("Display \"%s\" from introduction demo %d pixels from top", s[0], b[0]); outFile << t;break;

					case 0x67: outFile << "               Run Ending Credits";break;

					case 0x88:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Set Bit 7 of 00:%04X", (((0x7F & b[0]) * 0x10) + 0x0158)); outFile << t;break;

					case 0x89:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Clear Bit 7 of 00:%04X", (((0x7F & b[0]) * 0x10) + 0x0158)); outFile << t;break;

					case 0x8A:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("<UNKNOWN COMMAND $8A>"); outFile << t;break;

					case 0x8B:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Set Bit 3 of memory address 00:%04X", (((0x7F & b[0]) * 0x10) + 0x0158)); outFile << t;break;

					case 0x8C:
						file.Read(b, 3);
						t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t;
						t.Format("<UNKNOWN COMMAND $8C>"); outFile << t;break;

					case 0x8E:
						file.Read(b, 3);
						t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t;
						t.Format("<UNKNOWN COMMAND $8E>"); outFile << t;break;

					case 0x8F:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("<UNKNOWN COMMAND $8F>"); outFile << t;break;

					case 0x90:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("Store #$%02X to 00:0335 and #$%02X to 00:0336", b[0], b[1]); outFile << t;break;

					case 0x91: outFile << "               Store #$FF to 00:0335";break;

					case 0x92: outFile << "               Store #$01 to 00:0334";break;

					case 0x93: outFile << "               Store #$00 to 00:0334";break;

					case 0x94:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("<UNKNOWN COMMAND $94>"); outFile << t;break;

					case 0x95:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("<UNKNOWN COMMAND $95>"); outFile << t;break;

					case 0x96:
						file.Read(b, 3);
						t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t;
						t.Format("If value at 00:2143 = #$%02X jump to address $%02X/%02X%02X", b[0], (pc & 0xFF0000) >> 16, b[2], b[1]); outFile << t;break;

					case 0x97:
						file.Read(b, 3);
						t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t;
						t.Format("If value at 00:2143 != #$%02X jump to address $%02X/%02X%02X", b[0], (pc & 0xFF0000) >> 16, b[2], b[1]); outFile << t;break;

					case 0x98:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("<UNKNOWN COMMAND $98>"); outFile << t;break;

					case 0x9C:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Play sound effect #$%02X", b[0]); outFile << t;break;

					case 0x9D:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("Play sound effect #$%02X; Speaker balance: %d", b[0], b[1]); outFile << t;break;

					case 0x9E:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Play music #$%02X", b[0]); outFile << t;break;

					case 0x9F: outFile << "               Stop music playback";break;

					case 0xA0: outFile << "               Stop music playback";break;

					case 0xA1: outFile << "               Stop music playback";break;

					case 0xA2: outFile << "               Stop music playback";break;

					case 0xA3: outFile << "               Fade out music";break;

					case 0xA4: outFile << "               Slow down music";break;

					case 0xA5: outFile << "               Speed up music";break;

					case 0xA7: outFile << "               Stop music playback";break;

					case 0xA8:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Set event flag memory address 00:%04X Bit(s) $%01X", (((((0xA8 * 0x0100) + b[0]) - 0xA800) / 8) + 0x7040), (0x07 & b[0])); outFile << t;break;

					case 0xA9:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Set event flag memory address 00:%04X Bit(s) $%01X", (((((0xA9 * 0x0100) + b[0]) - 0xA800) / 8) + 0x7040), (0x07 & b[0])); outFile << t;break;

					case 0xAA:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Set event flag memory address 00:%04X Bit(s) $%01X", (((((0xAA * 0x0100) + b[0]) - 0xA800) / 8) + 0x7040), (0x07 & b[0])); outFile << t;break;
						break;

					case 0xAC:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Store value at 7F:%04X to 00:7000", ((((b[1] * 0x100) + b[0]) + 0xF800))); outFile << t;
						break;

					case 0xB0:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("Isolate Bits $%02X%02X of 00:7000", b[1], b[0]); outFile << t;
						break;

					case 0xB1:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("Set Bits $%02X%02X of 00:7000", b[1], b[0]); outFile << t;
						break;

					case 0xB2:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("XOR Bits $%02X%02X of 00:7000", b[1], b[0]); outFile << t;
						break;

					case 0xB3:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Read Bits from 00:%04X and isolate Bits in 00:7000", ((b[0] * 2) + 0x7000)); outFile << t;
						break;

					case 0xB4:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Read Bits from 00:%04X and set Bits in 00:7000", ((b[0] * 2) + 0x7000)); outFile << t;
						break;

					case 0xB5:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Read Bits from 00:%04X and XOR Bits in 00:7000", ((b[0] * 2) + 0x7000)); outFile << t;
						break;

					case 0xB6:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("Divide value at 00:%04X by 2^%d and store back", ((b[0] * 2) + 0x7000), ((b[1] ^ 0xFF) + 1)); outFile << t;
						break;

					case 0xB7:
						file.Read(b, 1);
						t.Format("%02X             ", b[0]); outFile << t;
						t.Format("Read value at 00:%04X and generate a random number between 0 and that value", ((b[0] * 2) + 0x7000)); outFile << t;
						break;

					case 0xB8: outFile << "               Store value at 7F:F8CD to 00:7000";break;

					case 0xC6: outFile << "               If Bit 0 set on 00:7018, clear 00:7016,00:7018 and isolate high byte of 00:701A";break;

					case 0xC8:
						file.Read(b, 2);
						t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
						t.Format("Multiply value at memory address 00:3148 with #$%02X, then add #$%02X, then double it and add to #$7FB000, then store the value at that memory address to 00:7000", b[1], b[0]); outFile << t;
						break;

					case 0xF0:
						file.Read(b, 4);
						t.Format("%02X %02X %02X %02X    ", b[0], b[1], b[2], b[3]); outFile << t;
						t.Format("<UNKNOWN COMMAND $%02X: pointer to address $%02X/%02X%02X", param, (pc & 0xFF0000) >> 16, b[3], b[2]); outFile << t;
						break;

					case 0xF8: outFile << "               Store value at 7F:F8CD to 00:7000";break;

					case 0xF9: outFile << "               Store value at 7F:F8CD to 00:7000";break;

					case 0xFA: outFile << "               Store value at 7F:F8CD to 00:7000";break;

					case 0xFB: outFile << "               Store value at 7F:F8CD to 00:7000";break;

					case 0xFC: outFile << "               Store value at 7F:F8CD to 00:7000";break;

					case 0xFD: outFile << "               Store value at 7F:F8CD to 00:7000";break;

					case 0xFE: outFile << "               Store value at 7F:F8CD to 00:7000";break;

					default: t.Format("               <UNKNOWN COMMAND $%02X %02X>", opcode, param); outFile << t;break;
					}

					break;

				default: 
					if(opcode >= 0x00 && opcode <= 0x2F)
					{
						file.Read(b, 1);
						param = b[0];
						t.Format("%02X ", param); outFile << t;

						switch(opcode)
						{
						case 0x00: s[0]="MARIO";break;
						case 0x01: s[0]="TOADSTOOL";break;
						case 0x02: s[0]="BOWSER";break;
						case 0x03: s[0]="GENO";break;
						case 0x04: s[0]="MALLOW";break;
						case 0x0C: s[0]="BG1,2,3 + MARIO + NPC";break;
						case 0x0D: s[0]="BG1";break;
						case 0x0E: s[0]="BG1 + MARIO";break;
						case 0x0F: s[0]="BG2 + NPC";break;
						default:
							if(opcode >= 0x14 && opcode <= 0x2F) s[0].Format("NPC #%d", opcode - 0x14);
							else s[0]="<UNKNOWN>";break;
						}

						if(param >= 0xF2 && param <= 0xFF)
						{
							switch(param)
							{
							case 0xF2:
								file.Read(b, 2);
								t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
								s[1].Format("Set object to movement: $%02X%02X", b[1], b[0]);break;

							case 0xF3:
								file.Read(b, 2);
								t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
								s[1].Format("Set object to movement: $%02X%02X", b[1], b[0]);break;

							case 0xF4:
								file.Read(b, 2);
								t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
								s[1].Format("UNKNOWN COMMAND $%02X: movement $%02X%02X", param, b[1], b[0]);break;

							case 0xF5:
								file.Read(b, 2);
								t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
								s[1].Format("UNKNOWN COMMAND $%02X: movement $%02X%02X", param, b[1], b[0]);break;

							case 0xF8:
								t.Format("               "); outFile << t;
								s[1].Format("Show Object");break;

							case 0xF9:
								t.Format("               "); outFile << t;
								s[1].Format("Remove Object");break;

							case 0xFA:
								t.Format("               "); outFile << t;
								s[1].Format("Remove movement effects");break;

							case 0xFD:
								t.Format("               "); outFile << t;
								s[1].Format("<UNKNOWN COMMAND $%02X>", param);break;

							case 0xFE:
								t.Format("               "); outFile << t;
								s[1].Format("End object queue");break;

							case 0xFF:
								file.Read(b, 1);
								t.Format("%02X             ", b[0]); outFile << t;
								s[1].Format("<UNKNOWN COMMAND $%02X>", param);break;

							default:
								outFile << "               ";
								s[1].Format("<UNKNOWN COMMAND $%02X>", param);break;
							}

							t.Format("Set Object: %s ---> Command: %s", s[0], s[1]); outFile << t;
						}

						if(param < 0xF2)
						{
							if(param == 0xF0 || param == 0xF1)
							{
								file.Read(b, 1);
								bQueueLen = b[0] & 0x7F;
								t.Format("%02X ", b[0]); outFile << t;
							}

							else
								bQueueLen = b[0] & 0x7F;

							t.Format("               Set Object: %s ---> Begin action queue for object (Length: 0x%02X bytes)", s[0], (0x7F & param)); outFile << t;

							if(param & 0x80)
							{
								t.Format(" (Wait until complete)"); outFile << t;
							}

							outFile << endl;

							if(lEnBytes)
							{
								file.Seek(lBakPtr, CFile::begin);
							}

							opcode = 0;

							dwQueueStart = file.GetPosition();

							while(file.GetPosition() < dwQueueStart + bQueueLen)
							{
								for(int i = 0; i < 16; i++)
								{
									b[i] = w[i] = d[i] = 0;
									s[i].Empty();
								}

								dwOffset = file.GetPosition();
								pc = dwOffset + 0xC00000;

								file.Read(&opcode, 1);

								t.Format("   %02X/%04X: %02X ", (pc & 0xFF0000) >> 16, pc & 0xFFFF, opcode);
								outFile << t;

								switch(opcode)
								{
								case 0x00: outFile << "                  Set Bit 7 of current object (enable object visibility)";break;

								case 0x01: outFile << "                  Clear Bit 7 of current object (disable object visibility)";break;

								case 0x02: outFile << "                  Set Bit 4,6 of current object (enable all sequence playback)";break;

								case 0x03: outFile << "                  Clear Bit 4,6 of current object (disable all sequence playback)";break;

								case 0x04: outFile << "                  Set Bit 4,5 of current object (enable constant sequence playback)";break;

								case 0x05: outFile << "                  Clear Bit 4,5 of current object (disable constant sequence playback)";break;

								case 0x06: outFile << "                  Set \"moon-walk\" Bits";break;

								case 0x07: outFile << "                  Clear \"moon-walk\" Bits";break;

								case 0x08:
									file.Read(b, 2);
									if(b[0] & 0x08)	s[0] = "yes";
									else s[0] = "no";
									if(b[0] & 0x10) s[1] = "yes";
									else s[1] = "no";
									if(b[0] & 0x40) s[2] = "yes";
									else s[2] = "no";
									if(b[1] & 0x80)	s[3] = "yes";
									else s[3] = "no";

									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Set animation/sequence\n"); outFile << t;
									t.Format("                                 ---> Object: %d\n", (b[0] & 7)); outFile << t;
									t.Format("                                 ---> Read from frame: %s\n", s[0]); outFile << t;
									t.Format("                                 ---> Play sequence only once: %s\n", s[1]); outFile << t;
									t.Format("                                 ---> Read from sequence: %s\n", s[2]); outFile << t;
									t.Format("                                 ---> Sequence/Frame: $%02X\n", (b[1] & 0x7F)); outFile << t;
									t.Format("                                 ---> Mirrored: %s", s[3]); outFile << t;
									break;

								case 0x09: outFile << "                  Reset all object properties to default";break;

								case 0x0A:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Store #$%02X to current object address 0A,x", b[0]); outFile << t;
									break;

								case 0x0B:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Set Bits $%01X of current object address 0A,x", b[0]); outFile << t;
									break;

								case 0x0C:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("XOR Bits $%01X of current object address 0A,x", b[0]); outFile << t;
									break;

								case 0x0D:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x0E:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x10:
									file.Read(b, 1);

									switch(b[0] & 0xC0)
									{
									case 0xC0: s[0] = "transition and sequence flags";break;
									case 0x40: s[0] = "transition flag";break;
									case 0x80: s[0] = "sequence flag";break;
									case 0x20: s[0] = "sequence flag";break;
									}

									switch(b[0] & 0x0F)
									{
									case 0x00: s[1] = "x1 speed";break;
									case 0x01: s[1] = "x2 speed";break;
									case 0x02: s[1] = "x3 speed";break;
									case 0x03: s[1] = "x4 speed";break;
									case 0x04: s[1] = "x8 speed";break;
									case 0x05: s[1] = "1/2 speed";break;
									case 0x06: s[1] = "1/4 speed";break;
									}

									t.Format("%02X                ", b[0]); outFile << t;
									t.Format("Set %s, %s", s[0], s[1]); outFile << t;
									break;

								case 0x11:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Isolate top Bits of current object address 0D,x and set Bit(s) $%d", b[0]); outFile << t;
									break;

								case 0x12:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Clear Bits $3 of current object address 0B,x and set Bit(s) $%d", b[0]); outFile << t;
									break;

								case 0x13:
									file.Read(b, 1);

									switch(b[0])
									{
									case 0x00: s[0] = "MARIO overlaps object";break;
									case 0x01: s[0] = "Normal";break;
									case 0x02: s[0] = "Object overlaps MARIO";break;
									case 0x03: s[0] = "...";break;
									}

									t.Format("%02X                ", b[0]); outFile << t;
									t.Format("Layering priority: %s", s[0]); outFile << t;
									break;

								case 0x14:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Isolate top Bits of current object address 0E,x and set Bit(s) $%d", b[0]); outFile << t;
									break;

								case 0x15:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Clear Bits $7 of current object address 0C,x and set Bit(s) $%d", b[0]); outFile << t;
									break;

								case 0x20:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x23:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x24:
									file.Read(b, 4);
									t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x25:
									file.Read(b, 4);
									t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x26:
									file.Read(b, 15);
									t.Format("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X ", b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x27:
									file.Read(b, 15);
									t.Format("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X ", b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x28:
									file.Read(b, 15);
									t.Format("%02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X ", b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x29:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x2B:
									file.Read(b, 4);
									t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x2C:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x2D:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x2E:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x2F:
									file.Read(b, 6);
									t.Format("%02X %02X %02X %02X %02X %02X ", b[0], b[1], b[2], b[3], b[4], b[5]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x30:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x31:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x32:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x33:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x34:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x35:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x3A:
									file.Read(b, 5);
									t.Format("%02X %02X %02X %02X %02X    ", b[0], b[1], b[2], b[3], b[4]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x3B:
									file.Read(b, 5);
									t.Format("%02X %02X %02X %02X %02X    ", b[0], b[1], b[2], b[3], b[4]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t;
									break;

								case 0x3C:
									file.Read(b, 4);
									t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X: pointer to address $%02X/%02X%02X>", opcode, (pc & 0xFF0000) >> 16, b[3], b[2]); outFile << t;
									break;

								case 0x3D:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X: pointer to address $%02X/%02X%02X>", opcode, (pc & 0xFF0000) >> 16, b[1], b[0]); outFile << t;
									break;

								case 0x3E:
									file.Read(b, 4);
									t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X: pointer to address $%02X/%02X%02X>", opcode, (pc & 0xFF0000) >> 16, b[3], b[2]); outFile << t;
									break;

								case 0x3F:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X: pointer to address $%02X/%02X%02X>", opcode, (pc & 0xFF0000) >> 16, b[2], b[1]); outFile << t;
									break;

								case 0x50:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object right %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x51:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object down-right %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x52:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object down %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x53:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object down-left %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x54:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object left %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x55:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object up-left %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x56:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object up %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x57:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object up-right %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x58:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object right %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x59: outFile << "                  Shift object right a lot";break;

								case 0x5A:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object up %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x5B:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object down %d pixels", (b[0] * 0x10)); outFile << t;
									break;

								case 0x5C: outFile << "                  Shift up forever";break;

								case 0x5D: outFile << "                  Shift down forever";break;

								case 0x60:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object right %d pixels", b[0]); outFile << t;
									break;

								case 0x61:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object down-right %d pixels", b[0]); outFile << t;
									break;

								case 0x62:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object down %d pixels", b[0]); outFile << t;
									break;

								case 0x63:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object down-left %d pixels", b[0]); outFile << t;
									break;

								case 0x64:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object left %d pixels", b[0]); outFile << t;
									break;

								case 0x65:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object up-left %d pixels", b[0]); outFile << t;
									break;

								case 0x66:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object up %d pixels", b[0]); outFile << t;
									break;

								case 0x67:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object up-right %d pixels", b[0]); outFile << t;
									break;

								case 0x68:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object right %d pixels", b[0]); outFile << t;
									break;

								case 0x69:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object right %d pixels", b[0]); outFile << t;
									break;

								case 0x6A:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Shift object up %d pixels", b[0]); outFile << t;
									break;

								case 0x6B:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND: frame duration=%d?>", b[0]); outFile << t; 
									break;

								case 0x70: outFile << "                  Object faces right";break;

								case 0x71: outFile << "                  Object faces down-right";break;

								case 0x72: outFile << "                  Object faces down";break;

								case 0x73: outFile << "                  Object faces down-left";break;

								case 0x74: outFile << "                  Object faces left";break;

								case 0x75: outFile << "                  Object faces up-left";break;

								case 0x76: outFile << "                  Object faces up";break;

								case 0x77: outFile << "                  Object faces up-right";break;

								case 0x78: outFile << "                  Object faces down";break;

								case 0x79: outFile << "                  Object turns down";break;

								case 0x7A: outFile << "                  Object turns in random directions";break;

								case 0x7B:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t; 
									break;

								case 0x7C: outFile << "                  Object faces right";break;

								case 0x7D: outFile << "                  Object faces down-left";break;

								case 0x7E:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Object jumps #$%02X%02X units", b[1], b[0]); outFile << t; 
									break;

								case 0x7F:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Object jumps (with sound effect) #$%02X%02X units", b[1], b[0]); outFile << t; 
									break;

								case 0x80:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Move object to on-screen coords: (%d,%d)", (((b[0] & 0x7F) * 0x20) + (0x10 * (b[1] & 1))), ((b[1] & 0x7F) * 8)); outFile << t; 
									break;

								case 0x81:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Move object: right=%dpx down=%dpx", (((b[0] & 0x7F) * 0x20) + (0x10 * (b[1] & 1))), ((b[1] & 0x7F) * 8)); outFile << t; 
									break;

								case 0x82:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Place object at on-screen coords: (%d,%d)", (((b[0] & 0x7F) * 0x20) + (0x10 * (b[1] & 1))), ((b[1] & 0x7F) * 8)); outFile << t; 
									break;

								case 0x83:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Place object: right=%dpx down=%dpx", (((b[0] & 0x7F) * 0x20) + (0x10 * (b[1] & 1))), ((b[1] & 0x7F) * 8)); outFile << t; 
									break;

								case 0x84:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t;
									t.Format("Place object: right=%dpx down=%dpx", b[0], b[1]); outFile << t; 
									break;

								case 0x85: outFile << "                  Max sequence speed?";break;

								case 0x86: outFile << "                  Max sequence speed?";break;

								case 0x87:
									file.Read(b, 1);

									switch(b[0])
									{
									case 0x00: s[0]="MARIO";break;
									case 0x01: s[0]="TOADSTOOL";break;
									case 0x02: s[0]="BOWSER";break;
									case 0x03: s[0]="GENO";break;
									case 0x04: s[0]="MALLOW";break;
									case 0x0C: s[0]="BG1,2,3 + MARIO + NPC";break;
									case 0x0D: s[0]="BG1";break;
									case 0x0E: s[0]="BG1 + MARIO";break;
									case 0x0F: s[0]="BG2 + NPC";break;
									default:
										if(opcode >= 0x14 && opcode <= 0x2F) s[0].Format("NPC #%d", opcode - 0x14);
										else s[0]="<UNKNOWN>";break;
									}

									t.Format("%02X                ", b[0]); outFile << t;
									t.Format("Transfer object to coords of %s", s[0]); outFile << t; 
									break;

								case 0x88: outFile << "                  Object runs away?";break;

								case 0x89: outFile << "                  Object disappears?";break;

								case 0x8A: outFile << "                  Object disappears?";break;

								case 0x90:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]); outFile << t; 
									t.Format("Objects bounces %dpx high to on-screen coords: (%d,%d)", b[2], (((b[0] & 0x7F) * 0x20) + (0x10 * (b[1] & 1))), ((b[1] & 0x7F) * 8)); outFile << t; 
									break;

								case 0x91:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]); outFile << t; 
									t.Format("Objects bounces at %dpx high arches: right=%dpx down=%dpx)", b[2], (((b[0] & 0x7F) * 0x20) + (0x10 * (b[1] & 1))), ((b[1] & 0x7F) * 8)); outFile << t; 
									break;

								case 0x92:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]); outFile << t; 
									t.Format("Place object at on-screen coords: (%d,%d) Z=%d", (((b[0] & 0x7F) * 0x20) + (0x10 * (b[1] & 1))), ((b[1] & 0x7F) * 8), ((b[2] & 0x1F) * 0x10)); outFile << t; 
									break;

								case 0x93:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]); outFile << t; 
									t.Format("Place object: right=%dpx down=%dpx up=%dpx", (((b[0] & 0x7F) * 0x20) + (0x10 * (b[1] & 1))), ((b[1] & 0x7F) * 8), ((b[2] & 0x1F) * 0x10)); outFile << t; 
									break;

								case 0x94:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]); outFile << t;
									t.Format("Place object: right=%dpx down=%dpx up=%dpx", b[0], b[1], b[2]); outFile << t; 
									break;

								case 0x95:
									file.Read(b, 1);

									switch(b[0])
									{
									case 0x00: s[0]="MARIO";break;
									case 0x01: s[0]="TOADSTOOL";break;
									case 0x02: s[0]="BOWSER";break;
									case 0x03: s[0]="GENO";break;
									case 0x04: s[0]="MALLOW";break;
									case 0x0C: s[0]="BG1,2,3 + MARIO + NPC";break;
									case 0x0D: s[0]="BG1";break;
									case 0x0E: s[0]="BG1 + MARIO";break;
									case 0x0F: s[0]="BG2 + NPC";break;
									default:
										if(opcode >= 0x14 && opcode <= 0x2F) s[0].Format("NPC #%d", opcode - 0x14);
										else s[0]="<UNKNOWN>";break;
									}

									t.Format("%02X                ", b[0]); outFile << t;
									t.Format("Transfer object to coords of %s", s[0]); outFile << t; 
									break;

								case 0x96:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t; 
									break;

								case 0x97:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t; 
									break;

								case 0x9B: outFile << "                  Stop sound effect";break;

								case 0x9C:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Play sound effect #$%02X", b[0]); outFile << t; 
									break;

								case 0x9D:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t; 
									break;

								case 0x9E:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t; 
									break;

								case 0x9F:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t; 
									break;

								case 0xA0:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Set event flag memory address 00:%04X Bit %01X", (((((opcode * 0x0100) + b[0]) - 0xA000) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

								case 0xA1:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Set event flag memory address 00:%04X Bit %01X", (((((opcode * 0x0100) + b[0]) - 0xA000) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

								case 0xA2:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Set event flag memory address 00:%04X Bit %01X", (((((opcode * 0x0100) + b[0]) - 0xA000) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

								case 0xA3: outFile << "                  Set memory address Bits using 00:700C";break;

								case 0xA4:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Clear event flag memory address 00:%04X Bit %01X", (((((opcode * 0x0100) + b[0]) - 0xA400) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

								case 0xA5:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Clear event flag memory address 00:%04X Bit %01X", (((((opcode * 0x0100) + b[0]) - 0xA400) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

								case 0xA6:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Clear event flag memory address 00:%04X Bit %01X", (((((opcode * 0x0100) + b[0]) - 0xA400) / 8) + 0x7040), (0x07 & b[0]));outFile << t;break;

								case 0xA7: outFile << "                  Clear memory address Bits using 00:700C";break;

								case 0xA8:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("Store #$%02X to 00:%04X", b[1], (0x70A0 + b[0]));outFile << t;break;

								case 0xA9:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("Add #$%02X to 00:%04X", b[1], (0x70A0 + b[0]));outFile << t;break;

								case 0xAA:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Increment 00:%04X", (b[0] + 0x70A0));outFile << t;break;

								case 0xAB:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Decrement 00:%04X", (b[0] + 0x70A0));outFile << t;break;

								case 0xAC:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("Store #$%02X%02X to 00:700C", b[1], b[0]);outFile << t;break;

								case 0xAD:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("Store #$%02X%02X to 00:700C", b[1], b[0]);outFile << t;break;

								case 0xAE: outFile << "                  Increment 00:700C";break;

								case 0xAF: outFile << "                  Decrement 00:700C";break;

								case 0xB0:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("Store #$%02X%02X to 00:%04X", b[2], b[1], (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xB1:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("Add #$%02X%02X to 00:%04X", b[2], b[1], (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xB2:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Increment 00:%04X", (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xB3:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Decrement 00:%04X", (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xB4:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Store value at 00:%04X to 00:700C", (0x70A0 + b[0]));outFile << t;break;

								case 0xB5:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Store value at 00:700C to 00:%04X", (0x70A0 + b[0]));outFile << t;break;

								case 0xB6:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("Store a random number from 0 to #$%02X%02X to 00:700C", b[1], b[0]);outFile << t;break;

								case 0xB7:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("Store a random number from 0 to #$%02X%02X to 00:%04X", b[2], b[1], (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xB8:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Add value at 00:%04X to 00:700C", (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xB9:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Subtract value at 00:%04X to 00:700C", (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xBA:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Store value at 00:%04X to 00:700C", (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xBB:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Store value at 00:700C to 00:%04X", (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xBC:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("Store value at 00:%04X to 00:%04X", (0x7000 + (b[0] * 2)), (0x7000 + (b[1] * 2)));outFile << t;break;

								case 0xBD:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("Exchange values at memory addresses 00:%04X and 00:%04X", (0x7000 + (b[0] * 2)), (0x7000 + (b[1] * 2)));outFile << t;break;

								case 0xBE: outFile << "                  Store values at addresses 00:7010,00:7012,00:7014 to 00:7016,00:7018,00:701A";break;

								case 0xBF: outFile << "                  Store values at addresses 00:7016,00:7018,00:701A to 00:7010,00:7012,00:7014";break;

								case 0xC0:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("Compare value at 00:700C to #$%02X%02X", b[1], b[0]);outFile << t;break;

								case 0xC1:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Compare values at memory addresses 00:%04X and 00:700C", (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xC2:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("Compare value at 00:%04X to #$%02X%02X", (0x7000 + (b[0] * 2)), b[2], b[1]);outFile << t;break;

								case 0xC4:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C4>";break;

								case 0xC5:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C5>";break;

								case 0xC6:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Store value at 00:%04X to 00:700C and clear 00:700D", (0x6004 + (b[0] * 0x60)));outFile << t;break;

								case 0xC7:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C7>";break;

								case 0xC8:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C8>";break;

								case 0xC9:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;outFile << "<UNKNOWN COMMAND $C9>";break;

								case 0xCA: outFile << "                  Store held joypad register to 00:700C,00:700D";break;

								case 0xCB: outFile << "                  Store joypad register to 00:700C,00:700D";break;

								case 0xD0:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Set object to movement $%02X%02X", b[1], b[0]); outFile << t; 
									break;

								case 0xD2:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]); outFile << t; 
									break;

								case 0xD3:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]); outFile << t; 
									break;

								case 0xD4:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Start code block, repeat %d times", b[0]);outFile << t;break;

								case 0xD5:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("<UNKNOWN COMMAND $D5>");outFile << t;break;

								case 0xD6:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]);outFile << t;
									t.Format("Store value at 00:%04X to object memory", (0x7000 + (b[0] * 2)));outFile << t;break;

								case 0xD7: outFile << "                  End of code block";break;

								case 0xD8:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("If event flag memory address 00:%04X Bit %01X set, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xD800) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

								case 0xD9:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("If event flag memory address 00:%04X Bit %01x set, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xD800) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

								case 0xDA:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("If event flag memory address 00:%04X Bit %01X set, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xD800) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

								case 0xDB:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("If Bit(s) set at memory address (set by value at 00:700C), jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

								case 0xDC:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("If event flag memory address 00:%04X Bit %01X clear, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xDC00) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

								case 0xDD:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("If event flag memory address 00:%04X Bit %01X clear, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xDC00) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

								case 0xDE:
									file.Read(b, 3);
									t.Format("%02X %02X %02X          ", b[0], b[1], b[2]);outFile << t;
									t.Format("If event flag memory address 00:%04X Bit %01X clear, jump to address $%02X/%02X%02X", (((((opcode * 0x0100) + b[0]) - 0xDC00) / 8) + 0x7040), (0x07 & b[0]), (pc & 0xFF0000) >> 16, b[2], b[1]);outFile << t;break;

								case 0xDF:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]);outFile << t;
									t.Format("If Bit(s) clear at memory address (set using value at 00:700C), jump to address $%02X/%02X%02X", (pc & 0xFF0000) >> 16, b[1], b[0]);outFile << t;break;

								case 0xF0:
									file.Read(b, 1);
									t.Format("%02X                ", b[0]); outFile << t; 
									t.Format("Frame Duration: %d", b[0]); outFile << t; 
									break;

								case 0xF1:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("Frame Duration: %d", ((b[1] * 0x100) + b[0])); outFile << t; 
									break;

								case 0xF2:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t; 
									break;

								case 0xF3:
									file.Read(b, 2);
									t.Format("%02X %02X             ", b[0], b[1]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X>", opcode); outFile << t; 
									break;

								case 0xF8:
									file.Read(b, 4);
									t.Format("%02X %02X %02X %02X       ", b[0], b[1], b[2], b[3]); outFile << t; 
									t.Format("<UNKNOWN COMMAND $%02X: pointer to address ", (pc & 0xFF0000) >> 16, b[3], b[2]); outFile << t; 
									break;

								case 0xFE: 
									outFile << "                  Return Queue";
									break;

								case 0xFF: 
									outFile << "                  Return Queue All\n";
									break;

								case 0xFD:
									file.Read(b, 1);
									param = b[0];
									t.Format("%02X ", param);
									outFile << t;

									switch(param)
									{
									case 0x00: t.Format("               Set Bit 7 of object address 0D,x (show object shadow)"); outFile << t;break;

									case 0x01: t.Format("               Clear Bit 7 of object address 0D,x (hide object shadow)"); outFile << t;break;

									case 0x02: t.Format("               Set Bit 7 of object address 0C,x (object on ground)"); outFile << t;break;

									case 0x03: t.Format("               Clear Bit 6,7 of object address 0C,x (object floats)"); outFile << t;break;

									case 0x04: t.Format("               Set Bit 4 of object address 0E,x"); outFile << t;break;

									case 0x05: t.Format("               Clear Bit 4 of object address 0E,x"); outFile << t;break;

									case 0x06: t.Format("               Set Bit 5 of object address 0E,x"); outFile << t;break;

									case 0x07: t.Format("               Clear Bit 5 of object address 0E,x"); outFile << t;break;

									case 0x08: t.Format("               Set Bit 7 of object address 09,x"); outFile << t;break;

									case 0x09: t.Format("               Clear Bit 7 of object address 09,x"); outFile << t;break;

									case 0x0A: t.Format("               Set Bit 4 of object address 08,x"); outFile << t;break;

									case 0x0B: t.Format("               Clear Bit 3,4 of object address 08,x"); outFile << t;break;

									case 0x0C: t.Format("               Clear Bit 4 of object address 30,x (show object shadow)"); outFile << t;break;

									case 0x0D: t.Format("               Set Bit 4 of object address 30,x (hide object shadow)"); outFile << t;break;

									case 0x0E: t.Format("               Set Bit 5 and clear Bit 4,6 of object address 09,x (hide object shadow)"); outFile << t;break;

									case 0x0F:
										file.Read(b, 1);

										if(b[0] == 0x02) s[0] = "BG1";
										else if(b[0] == 0x03) s[0] = "BG1 & BG2";
										else s[0] = "<UNKNOWN>";

										t.Format("%02X             ", b[0]); outFile << t; 
										t.Format("Object overlaps %s", s[0]); outFile << t; 
										break;

									case 0x10: t.Format("               Clear Bit 5 of object address 12,x"); outFile << t;break;

									case 0x11: t.Format("               Set Bit 5 of object address 12,x"); outFile << t;break;

									case 0x13: t.Format("               Clear Bit 3,4,5 of object address 0C,x"); outFile << t;break;

									case 0x14: t.Format("               Set Bit 3,4,5 of object address 0C,x"); outFile << t;break;

									case 0x15: t.Format("               Set Bit 4 and clear Bit 3,5 of object address 0C,x"); outFile << t;break;

									case 0x16: t.Format("               Clear Bit 3 of object address 0B,x"); outFile << t;break;

									case 0x17: t.Format("               Set Bit 3 of object address 0B,x"); outFile << t;break;

									case 0x18: t.Format("               Set Bit 6 of object address 3C,x"); outFile << t;break;

									case 0x19: t.Format("               Set Bit 6 of object address 0D,x"); outFile << t;break;

									case 0x20:
										file.Read(b, 3);
										t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t; 
										t.Format("<UNKNOWN COMMAND $%02X>", param); outFile << t; 
										break;

									case 0x23:
										file.Read(b, 2);
										t.Format("%02X %02X          ", b[0], b[1]); outFile << t; 
										t.Format("<UNKNOWN COMMAND $%02X>", param); outFile << t; 
										break;

									case 0x24:
										file.Read(b, 2);
										t.Format("%02X %02X          ", b[0], b[1]); outFile << t; 
										t.Format("<UNKNOWN COMMAND $%02X>", param); outFile << t; 
										break;

									case 0x30:
										file.Read(b, 6);
										t.Format("%02X %02X %02X %02X %02X %02X ", b[0], b[1], b[2], b[3], b[4], b[5]); outFile << t;
										t.Format("<UNKNOWN COMMAND $30>"); outFile << t; 
										break;

									case 0x31:
										file.Read(b, 6);
										t.Format("%02X %02X %02X %02X %02X %02X ", b[0], b[1], b[2], b[3], b[4], b[5]); outFile << t;
										t.Format("<UNKNOWN COMMAND $31>"); outFile << t; 
										break;

									case 0x32:
										file.Read(b, 6);
										t.Format("%02X %02X %02X %02X %02X %02X ", b[0], b[1], b[2], b[3], b[4], b[5]); outFile << t;
										t.Format("<UNKNOWN COMMAND $32>"); outFile << t; 
										break;

									case 0x33:
										file.Read(b, 3);
										t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t; 
										t.Format("<UNKNOWN COMMAND $%02X>", param); outFile << t; 
										break;

									case 0x3D:
										file.Read(b, 3);
										t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t; 
										t.Format("<UNKNOWN COMMAND $%02X: pointer to address ", (pc & 0xFF0000) >> 16, b[2], b[1]); outFile << t; 
										break;

									case 0x3E:
										file.Read(b, 5);
										t.Format("%02X %02X %02X %02X %02X ", b[0], b[1], b[2], b[3], b[4]); outFile << t; 
										t.Format("<UNKNOWN COMMAND $%02X: pointer to address ", (pc & 0xFF0000) >> 16, b[4], b[3]); outFile << t; 
										break;

									case 0x3F:
										file.Read(b, 3);
										t.Format("%02X %02X %02X       ", b[0], b[1], b[2]); outFile << t; 
										t.Format("<UNKNOWN COMMAND $%02X: pointer to address ", (pc & 0xFF0000) >> 16, b[2], b[1]); outFile << t; 
										break;

									case 0xB0:
										file.Read(b, 2);
										t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
										t.Format("Isolate Bits $%02X%02X of 00:700C", b[1], b[0]); outFile << t;
										break;

									case 0xB1:
										file.Read(b, 2);
										t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
										t.Format("Set Bits $%02X%02X of 00:700C", b[1], b[0]); outFile << t;
										break;

									case 0xB2:
										file.Read(b, 2);
										t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
										t.Format("XOR Bits $%02X%02X of 00:700C", b[1], b[0]); outFile << t;
										break;

									case 0xB3:
										file.Read(b, 1);
										t.Format("%02X             ", b[0]); outFile << t;
										t.Format("Read Bits from 00:%04X and isolate Bits in 00:700C", ((b[0] * 2) + 0x7000)); outFile << t;
										break;

									case 0xB4:
										file.Read(b, 1);
										t.Format("%02X             ", b[0]); outFile << t;
										t.Format("Read Bits from 00:%04X and set Bits in 00:700C", ((b[0] * 2) + 0x7000)); outFile << t;
										break;

									case 0xB5:
										file.Read(b, 1);
										t.Format("%02X             ", b[0]); outFile << t;
										t.Format("Read Bits from 00:%04X and XOR Bits in 00:700C", ((b[0] * 2) + 0x7000)); outFile << t;
										break;

									case 0xB6:
										file.Read(b, 2);
										t.Format("%02X %02X          ", b[0], b[1]); outFile << t;
										t.Format("Divide value at 00:%04X by 2^%d and store back", ((b[0] * 2) + 0x7000), ((b[1] ^ 0xFF) + 1)); outFile << t;
										break;

									case 0xC8:
										file.Read(b, 2);
										t.Format("%02X %02X          ", b[0], b[1]); outFile << t; 
										t.Format("<UNKNOWN COMMAND $%02X>", param); outFile << t; 
										break;

									default: t.Format("               <UNKNOWN COMMAND $%02X>", param); outFile << t;break;
									}

									break;

								default: t.Format("                  <UNKNOWN COMMAND $%02X>", opcode); outFile << t;break;
								}

								if(opcode == 0xFE || opcode == 0xFF)
								{
									outFile << endl << endl;
									break;
								}

								outFile << endl;
							}
						}
					}
					else 
					{
						t.Format("                  <UNKNOWN COMMAND $%02X>", opcode);
						outFile << t;
					}
					break;
				}

				if(!dwQueueStart) outFile << endl;
				dwOffset = file.GetPosition();
		}
		outFile << endl;
	}

	outFile.close();
	file.Close();
}

void readDialogue(CFile* m_pFile)
{
	WORD wPageBound = 0;
	m_pFile->Seek(0x37E000, CFile::begin);
	m_pFile->Read(&wPageBound, 2);

	BYTE bTemp[1024];

	for(DWORD i = 0x37E000; i < 0x37FFFE; i += 2)
	{
		int nPos = 0;

		DialogueItem* pDlg = new DialogueItem;
		dialogue.Add(pDlg);

		WORD wBegin = 0, wEnd = 0;
		m_pFile->Seek(i, CFile::begin);
		m_pFile->Read(&wBegin, 2);
		m_pFile->Read(&wEnd, 2);

		DWORD dwBegin = wBegin, dwEnd = wEnd;
		DWORD dwLength = dwEnd - dwBegin;

		if(dwLength)
		{
			BYTE bChar;

			if(((i - 0x37E000) / 2) + 1 >= 0x000E00)
			{
				m_pFile->Seek(dwBegin + 0x24531E, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000C00)
			{
				m_pFile->Seek(dwBegin + 0x240004, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000A01)
			{
				m_pFile->Seek(dwBegin + 0x237583, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000801)
			{
				m_pFile->Seek(dwBegin + 0x230004, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000601)
			{
				m_pFile->Seek(dwBegin + 0x22B2B8, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000401)
			{
				m_pFile->Seek(dwBegin + 0x226759, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000201)
			{
				m_pFile->Seek(dwBegin + 0x2206E3, CFile::begin);
			}

			else
			{
				m_pFile->Seek(dwBegin + 0x220008, CFile::begin);
			}

			m_pFile->Read(&bChar, 1);


			while(bChar)
			{
				if(bChar == 0x0B || bChar == 0x0D || bChar == 0x1C)
				{
					bTemp[nPos++] = bChar;
					m_pFile->Read(&bChar, 1);
				}
				bTemp[nPos++] = bChar;
				m_pFile->Read(&bChar, 1);
			}

			bTemp[nPos++] = 0x00;

			pDlg->text = new BYTE[nPos];
			pDlg->length = nPos;
			CopyMemory(pDlg->text, bTemp, nPos);

		}

		else
		{
			pDlg->text = NULL;
			pDlg->length = 0;
		}
	}

	// Read item data.
	m_pFile->Seek(0x3A46EF, CFile::begin);
	for(int n = 0; n < 256; n++)
		m_pFile->Read(items[n].name, 15);

}


CString g_dteTable[] = {
	//		0,    1,    2,    3,    4,    5,    6,    7,    8,    9,    A,    B,    C,    D,    E,    F
	/* 0 */ "<I><END>\n", "\n", "<I>\n", "<I>\n\n", "\n\n", "<I>", "\n\n", ">>", "  ", "   ", "    ", "", "", "", " the", " you",
	/* 1 */ "in", " to ", "'s ", "Mario", " I ", " and ", "is ", " so", "Mario", "Mario", "<ITEM>", "", "", "", "", "",
	/* 2 */ " ", "!", "�", "�", "{heart}", "{music}", "�", "�", " (", ")", ".", "..", ",", "-", ".", "/",
	/* 3 */ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "~", "@", "@", "@", "@", "?",
	/* 4 */ "", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O",
	/* 5 */ "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "", "", "", "", "",
	/* 6 */ "", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o",
	/* 7 */ "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "", "", "", "", "",
	/* 8 */ "", "", "", "", "", "", "", "", "", "", "", "", "", "", ":", ";", 
	/* 9 */ "<", ">", "...", "#", "+", "�", "%", "@", "@", "@", "*", "'", "&", "", "", ""
};

DialogueItem::DialogueItem()
{
}

DialogueItem::~DialogueItem()
{
	if(length != 0 && text) delete text;
}

void DialogueItem::ConvertToASCII(CString& str, DWORD tag, DWORD value, ... )
{
	DWORD propTag = tag;
	DWORD propValue = value;
	CMap<DWORD, DWORD, DWORD, DWORD> tagColl;

	va_list marker;
	va_start(marker, value);
	while(propTag != TAG_END)
	{
		tagColl[propTag] = propValue;
		propTag = va_arg(marker, DWORD);
		propValue = va_arg(marker, DWORD);
	}
	va_end(marker);

	BOOL bTagFound = FALSE;
	DWORD dwValue = 0;

	DWORD dwMode = 0;
	bTagFound = tagColl.Lookup(DI_ConvertMode, dwValue);
	if(bTagFound)
		dwMode = (DWORD)dwValue;
	else
		return;

	int nOffset = 0;
	bTagFound = tagColl.Lookup(DI_Offset, dwValue);
	if(bTagFound)
		nOffset = (int)dwValue;
	else
		nOffset = 0;

	str.Empty();

	for(int i = nOffset; i < length; i++)
	{
		if(text[i] == 0x06)
			return;

		if(text[i] == 0x0B)
		{
			CString t;
			i++;
			BYTE param = text[i];
			BYTE counter = 0;

			while(counter <= param)
			{
				str += t;

				counter++;
				param = text[i];
				t.Format(" ");
			}
		}

		else if(text[i] == 0x0D)
		{

			BYTE param = text[i];

			CString t;  t.Format("<pause %d frames>", param);
			str += t;
		}

		else if(text[i] == 0x1C)
		{
			CString t;
			i++;
			BYTE param = text[i];

			t.Format("<$%02X>", param);

			str += t;
		}

		else if(text[i] >= 0x00 && text[i] <= 0x9C)
		{
			str += g_dteTable[text[i]];
		}

		else
		{
			CString t;
			t.Format("<%02X>", text[i]);
			str += t;
		}
	}

	return;
}

CString FixedTextToCString(BYTE* text, int length, DWORD tag, DWORD value, ... )
{
	DWORD propTag = tag;
	DWORD propValue = value;
	CMap<DWORD, DWORD, DWORD, DWORD> tagColl;

	va_list marker;
	va_start(marker, value);
	while(propTag != TAG_END)
	{
		tagColl[propTag] = propValue;
		propTag = va_arg(marker, DWORD);
		propValue = va_arg(marker, DWORD);
	}
	va_end(marker);

	BOOL bTagFound = FALSE;
	DWORD dwValue = 0;

	BOOL bTrim = 0;
	bTagFound = tagColl.Lookup(TTCS_TrimTrailingSpaces, dwValue);
	if(bTagFound)
		bTrim = (BOOL)dwValue;
	else
		bTrim = FALSE;

	CString str;

	for(int i = 0; i < length; i++)
	{
		if(text[i] >= 0x00 && text[i] <= 0x9C)
		{
			str += g_dteTable[text[i] - 0x00];
		}

		else
		{
			CString t;
			t.Format("<%02X>", text[i]);
			str += t;
		}
	}

	return str;
}


int serialise_script(CString iScriptFn, CString iFf6Fn)
{
	CStdioFile inFile;
	if(inFile.Open(iScriptFn, CFile::typeText) == NULL)
	{
		printf(_T("Errors reading %s\n"), iScriptFn);
		return -1;
	}

	CString lScriptFn = iScriptFn;
	CFile outFile;
	if(outFile.Open(iFf6Fn, CFile::modeReadWrite|CFile::typeBinary) == NULL)
	{
		printf(_T("Errors opening %s for writting\n"), iFf6Fn);
		return -1;
	}
	outFile.Seek(SCRIPT_START, CFile::begin);

	//	CStdioFile inFile("D:\\0Data\\myprog\\FF3hack\\utilities\\win32\\EventDisasm\\eventdump.txt", CFile::typeText); //CFile::modeRead);
	//	CFile outFile;
	//	outFile.Open("D:\\0Data\\myprog\\FF3hack\\utilities\\win32\\EventDisasm\\reserialised.bin", CFile::modeCreate|CFile::modeWrite|CFile::typeBinary);

	CString lFileStr;
	char *lStrPtr;
	char *lDebugPtr;
	int lCnt, lCnt2;
	BYTE lConvByte;
	do
	{
		lFileStr.Empty();
		inFile.ReadString(lFileStr);
		lStrPtr = lFileStr.GetBuffer(0);

		if(lFileStr.GetLength()==0)
			break;

		// eliminates PC
		lCnt = 0;
		while(lStrPtr[lCnt] != ':')
			lCnt++;
		lCnt++;

		// eliminates spaces
		while(lStrPtr[lCnt] == ' ')
			lCnt++;

		// process hex
		lCnt2 = 0;
		lConvByte = 0;
		lDebugPtr = &lStrPtr[lCnt];
		while((lStrPtr[lCnt] != '\n') && (lStrPtr[lCnt] != '\0'))
		{
			if(lCnt2%2)
			{
				lConvByte |= ascii2nibble(lStrPtr[lCnt]);
				outFile.Write(&lConvByte, 1);
				lConvByte = 0;
			}
			else
				lConvByte = ascii2nibble(lStrPtr[lCnt])<<4;

			lCnt2++;
			lCnt++;
		}

	} while (lFileStr.GetLength()!=0);

	outFile.Close();
	inFile.Close();

	return 0;
}

BYTE ascii2nibble(BYTE iAsciiChar)
{
	if(iAsciiChar>='a' && iAsciiChar<='f')
	{
		iAsciiChar -= 'a';
		iAsciiChar += 0xA;
	}
	else if(iAsciiChar>='A' && iAsciiChar<='F')
	{
		iAsciiChar -= 'A';
		iAsciiChar += 0xA;
	}
	else if(iAsciiChar>='0' && iAsciiChar<='9')
	{
		iAsciiChar -= '0';
	}
	else
		iAsciiChar = 0xC;

	return(iAsciiChar);
}
