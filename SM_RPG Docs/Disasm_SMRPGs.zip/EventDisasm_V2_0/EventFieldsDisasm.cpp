// EventDisasm.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "EventDisasm.h"
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

#define HEXSCRIPT_FN	_T("EventFieldsHex.txt")
#define TXTSCRIPT_FN	_T("EventFieldsTxt.txt")

#define SCRIPT_START	0x1D2D64
#define SCRIPT_END		0x1D3165

#define POINTER_START	0x20E000
#define POINTER_END		0x20E3FF

CWinApp theApp;
CTypedPtrArray<CPtrArray, DialogueItem*> dialogue;
Item items[256];
Esper espers[27];
Character characters[64];

CString g_strColorComponents[] =
{
	"None", "None",
	"Red", "Red",
	"Green", "Green",
	"Yellow [Red + Green]", "Yellow [Red + Green]",
	"Blue", "Blue",
	"Magenta [Red + Blue]", "Magenta [Red + Blue]",
	"Cyan [Green + Blue]", "Cyan [Green + Blue]",
	"White [Red + Green + Blue]", "White [Red + Green + Blue]",
};

void realMain(int iTextMode, CString iFf6Fn);
void readDialogue(CFile* m_pFile);
int serialise_script(CString iScriptFn, CString iFf6Fn);
BYTE ascii2nibble(BYTE iAsciiChar);



int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		BOOL lDoTextDecode = FALSE;
		BOOL lDoHexDecode = FALSE;
		BOOL lDoHexEncode = FALSE;
		BOOL lDoGetHelp = FALSE;
		CString lTmpStr;
		CString lRomFn, lScriptFn;

		printf(_T("EventDisasm Version for SMRPG\n\n"));
		printf(_T("Original findings & code by Yousei, Jan. 2000\n"));
		printf(_T("Modified by Lord J, March 2005\n"));
		printf(_T("Modified by giangurgolo, January 2007\n\n"));

		if(argc<3)
			lDoGetHelp = TRUE;
		else
		{
			if( !strcmp(argv[1], _T("/dt")) || !strcmp(argv[1], _T("-dt")) )
				lDoTextDecode = TRUE;
			else if( !strcmp(argv[1], _T("/eh")) || !strcmp(argv[1], _T("-eh")) )
				lDoHexEncode = TRUE;
			else
				lDoGetHelp = TRUE;

			lRomFn = argv[2];

			if(lDoHexEncode && (argc<4))
				lDoGetHelp = TRUE;
			else if(lDoHexEncode)
				lScriptFn = argv[3];
		}

		if(lDoGetHelp)
		{
			printf(_T("Usage\n"));
			printf(_T("EventDisasm /dt <SMRPG image>: decode game script in text mode\n"));
			printf(_T("EventDisasm /eh <SMRPG image> <hex script> : encode game script in hex mode\n"));
			printf(_T("EventDisasm /? : this help message\n\n"));
		}
		else
		{
			if(lDoTextDecode)
			{
				printf(_T("Exporting %s's script to text file...\n"), lRomFn);
			}
			else // if(lDoHexEncode)
			{
				printf(_T("Merging %s hex script with %s...\n"), lScriptFn, lRomFn);
			}

			if(lDoTextDecode || lDoHexDecode)
			{
				realMain(lDoTextDecode, lRomFn);
				for(int i = 0; i < dialogue.GetSize(); i++)
					delete dialogue[i];
				dialogue.RemoveAll();
			}
			else if(lDoHexEncode)
				serialise_script(lScriptFn, lRomFn);
		}
	}

	return nRetCode;
}


void realMain(int iTextMode, CString iFf6Fn)
{
	CFile file;

	if(file.Open(iFf6Fn, CFile::modeRead) == NULL)
	{
		printf(_T("Errors reading %s\n"), iFf6Fn);
		return;
	}

	ofstream outFile;
	CString lScriptFn = iTextMode?TXTSCRIPT_FN:HEXSCRIPT_FN;
	outFile.open(lScriptFn);
	if(outFile == NULL)
	{
		printf(_T("Errors creating %s\n"), lScriptFn);
		return;
	}

	readDialogue(&file);

	DWORD dwOffset = 0;
	DWORD pOffset = 0;
	DWORD pPointer = 0;
	DWORD pc;
	DWORD dwQueueStart = 0;
	WORD eCounter = 0;
	BYTE bQueueLen = 0;
	BYTE objCount = 0;
	BYTE objCounter = 0;
	BYTE npcCounter = 1;
	BOOL npcMult = FALSE;

	CString t;
	BYTE b[16];
	WORD w[16];
	DWORD d[16];
	CString s[16];
	BOOL bFirst;
	BOOL bitCheck;
	BOOL nesFlag = FALSE;
	BOOL areaFlag = FALSE;
	BOOL mapFlag = FALSE;
	BOOL twoUnitFlag = FALSE;
	int nChoices = 0;
	int x, y;
	int lEnTxt = 0;
	int lEnBytes = 1;
	int lBakPtr;

	file.Seek(POINTER_START, CFile::begin);

	lEnTxt = iTextMode?1:0;
	lEnBytes = iTextMode?0:1;

	pPointer = file.GetPosition();

	while(pPointer < POINTER_END)
	{
		npcCounter = 1;

		for(int i = 0; i < 16; i++)
		{
			b[i] = w[i] = d[i] = 0;
			s[i].Empty();
		}

		file.Read(w, 4);

		dwOffset = 0x200000 + w[0];
		dwQueueStart = 0x200000 + w[0];
		pc = dwOffset + 0xC00000;

		bQueueLen = w[1] - w[0];

		t.Format("AREA [%03X] ------------------------------------------------------------>", eCounter); outFile << t << endl;

		file.Seek(dwOffset, CFile::begin);
		dwQueueStart = file.GetPosition();

		file.Read(b, 1);
		t.Format("%02X/%04X: %02X            New area's Music: #$%02X", (pc & 0xFF0000) >> 16, pc & 0xFFFF, b[0], b[0]); outFile << t << endl;

		pc = file.GetPosition() + 0xC00000;

		file.Read(b, 2);
		t.Format("%02X/%04X: %02X %02X         Exit Event: #$%02X%02X", (pc & 0xFF0000) >> 16, pc & 0xFFFF, b[0], b[1], b[1], b[0]); outFile << t << endl << endl;

		pc = file.GetPosition() + 0xC00000;

		while(file.GetPosition() < dwQueueStart + bQueueLen)
		{
			for(int i = 0; i < 16; i++)
			{
				b[i] = w[i] = d[i] = 0;
				s[i].Empty();
			}

			pc = file.GetPosition() + 0xC00000;
			nesFlag = FALSE;
			areaFlag = FALSE;
			mapFlag = FALSE;
			twoUnitFlag = FALSE;

			file.Read(b, 2);

			if(b[1] & 0x80)
			{
				s[1] = "more than 1 unit";
				twoUnitFlag = TRUE;
			}
			else 
			{
				s[1] = "only 1 unit";
				twoUnitFlag = FALSE;
			}

			t.Format("%02X/%04X: %02X %02X         Event: #$%02X%02X", (pc & 0xFF0000) >> 16, pc & 0xFFFF, b[0], b[1], b[1] & 0x0F, b[0]); outFile << t << endl;

			pc = file.GetPosition() + 0xC00000;

			file.Read(b, 3);
			t.Format("%02X/%04X: %02X %02X %02X      Field Coords: (%d,%d) Z=%dpx H=%dpx", (pc & 0xFF0000) >> 16, pc & 0xFFFF, b[0], b[1], b[2], (((b[0] & 0x7F) * 0x20) + (0x10 * (b[1] & 1))), ((b[1] & 0x7F) * 8), ((b[2] & 0x1F) * 0x10), ((b[2] >> 5) * 0x10)); outFile << t << endl;

			pc = file.GetPosition() + 0xC00000;

			if(twoUnitFlag)
			{
			file.Read(b, 1);
			if(b[0] & 0x80) s[0] = "135�";
			else s[0] = "45�";
			t.Format("%02X/%04X: %02X            Field Width: x%d", (pc & 0xFF0000) >> 16, pc & 0xFFFF, b[0], b[0] & 0x0F); outFile << t << endl;
			t.Format("                       Position: %s", s[0]); outFile << t << endl;

			pc = file.GetPosition() + 0xC00000;
			}

			outFile << endl;
			dwOffset = file.GetPosition();
		}

		eCounter++;
		pPointer += 2;
		file.Seek(pPointer, CFile::begin);

	}
	outFile.close();
	file.Close();
}

void readDialogue(CFile* m_pFile)
{
	WORD wPageBound = 0;
	m_pFile->Seek(0x37E000, CFile::begin);
	m_pFile->Read(&wPageBound, 2);

	BYTE bTemp[1024];

	for(DWORD i = 0x37E000; i < 0x37FFFE; i += 2)
	{
		int nPos = 0;

		DialogueItem* pDlg = new DialogueItem;
		dialogue.Add(pDlg);

		WORD wBegin = 0, wEnd = 0;
		m_pFile->Seek(i, CFile::begin);
		m_pFile->Read(&wBegin, 2);
		m_pFile->Read(&wEnd, 2);

		DWORD dwBegin = wBegin, dwEnd = wEnd;
		DWORD dwLength = dwEnd - dwBegin;

		if(dwLength)
		{
			BYTE bChar;

			if(((i - 0x37E000) / 2) + 1 >= 0x000E00)
			{
				m_pFile->Seek(dwBegin + 0x24531E, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000C00)
			{
				m_pFile->Seek(dwBegin + 0x240004, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000A01)
			{
				m_pFile->Seek(dwBegin + 0x237583, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000801)
			{
				m_pFile->Seek(dwBegin + 0x230004, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000601)
			{
				m_pFile->Seek(dwBegin + 0x22B2B8, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000401)
			{
				m_pFile->Seek(dwBegin + 0x226759, CFile::begin);
			}

			else if(((i - 0x37E000) / 2) + 1 >= 0x000201)
			{
				m_pFile->Seek(dwBegin + 0x2206E3, CFile::begin);
			}

			else
			{
				m_pFile->Seek(dwBegin + 0x220008, CFile::begin);
			}

			m_pFile->Read(&bChar, 1);


			while(bChar)
			{
				if(bChar == 0x0B || bChar == 0x0D || bChar == 0x1C)
				{
					bTemp[nPos++] = bChar;
					m_pFile->Read(&bChar, 1);
				}
				bTemp[nPos++] = bChar;
				m_pFile->Read(&bChar, 1);
			}

			bTemp[nPos++] = 0x00;

			pDlg->text = new BYTE[nPos];
			pDlg->length = nPos;
			CopyMemory(pDlg->text, bTemp, nPos);

		}

		else
		{
			pDlg->text = NULL;
			pDlg->length = 0;
		}
	}

	// Read item data.
	m_pFile->Seek(0x3A46EF, CFile::begin);
	for(int n = 0; n < 256; n++)
		m_pFile->Read(items[n].name, 15);

}


CString g_dteTable[] = {
	//		0,    1,    2,    3,    4,    5,    6,    7,    8,    9,    A,    B,    C,    D,    E,    F
	/* 0 */ "<I><END>\n", "\n", "<I>\n", "<I>\n\n", "\n\n", "<I>", "\n\n", ">>", "  ", "   ", "    ", "", "", "", " the", " you",
	/* 1 */ "in", " to ", "'s ", "Mario", " I ", " and ", "is ", " so", "Mario", "Mario", "<ITEM>", "", "", "", "", "",
	/* 2 */ " ", "!", "�", "�", "{heart}", "{music}", "�", "�", " (", ")", ".", "..", ",", "-", ".", "/",
	/* 3 */ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "~", "@", "@", "@", "@", "?",
	/* 4 */ "", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O",
	/* 5 */ "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "", "", "", "", "",
	/* 6 */ "", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o",
	/* 7 */ "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "", "", "", "", "",
	/* 8 */ "", "", "", "", "", "", "", "", "", "", "", "", "", "", ":", ";", 
	/* 9 */ "<", ">", "...", "#", "+", "�", "%", "@", "@", "@", "*", "'", "&", "", "", ""
};

DialogueItem::DialogueItem()
{
}

DialogueItem::~DialogueItem()
{
	if(length != 0 && text) delete text;
}

void DialogueItem::ConvertToASCII(CString& str, DWORD tag, DWORD value, ... )
{
	DWORD propTag = tag;
	DWORD propValue = value;
	CMap<DWORD, DWORD, DWORD, DWORD> tagColl;

	va_list marker;
	va_start(marker, value);
	while(propTag != TAG_END)
	{
		tagColl[propTag] = propValue;
		propTag = va_arg(marker, DWORD);
		propValue = va_arg(marker, DWORD);
	}
	va_end(marker);

	BOOL bTagFound = FALSE;
	DWORD dwValue = 0;

	DWORD dwMode = 0;
	bTagFound = tagColl.Lookup(DI_ConvertMode, dwValue);
	if(bTagFound)
		dwMode = (DWORD)dwValue;
	else
		return;

	int nOffset = 0;
	bTagFound = tagColl.Lookup(DI_Offset, dwValue);
	if(bTagFound)
		nOffset = (int)dwValue;
	else
		nOffset = 0;

	str.Empty();

	for(int i = nOffset; i < length; i++)
	{
		if(text[i] == 0x06)
			return;

		if(text[i] == 0x0B)
		{
			CString t;
			i++;
			BYTE param = text[i];
			BYTE counter = 0;

			while(counter <= param)
			{
				str += t;

				counter++;
				param = text[i];
				t.Format(" ");
			}
		}

		else if(text[i] == 0x0D)
		{

			BYTE param = text[i];

			CString t;  t.Format("<pause %d frames>", param);
			str += t;
		}

		else if(text[i] == 0x1C)
		{
			CString t;
			i++;
			BYTE param = text[i];

			t.Format("<$%02X>", param);

			str += t;
		}

		else if(text[i] >= 0x00 && text[i] <= 0x9C)
		{
			str += g_dteTable[text[i]];
		}

		else
		{
			CString t;
			t.Format("<%02X>", text[i]);
			str += t;
		}
	}

	return;
}

CString FixedTextToCString(BYTE* text, int length, DWORD tag, DWORD value, ... )
{
	DWORD propTag = tag;
	DWORD propValue = value;
	CMap<DWORD, DWORD, DWORD, DWORD> tagColl;

	va_list marker;
	va_start(marker, value);
	while(propTag != TAG_END)
	{
		tagColl[propTag] = propValue;
		propTag = va_arg(marker, DWORD);
		propValue = va_arg(marker, DWORD);
	}
	va_end(marker);

	BOOL bTagFound = FALSE;
	DWORD dwValue = 0;

	BOOL bTrim = 0;
	bTagFound = tagColl.Lookup(TTCS_TrimTrailingSpaces, dwValue);
	if(bTagFound)
		bTrim = (BOOL)dwValue;
	else
		bTrim = FALSE;

	CString str;

	for(int i = 0; i < length; i++)
	{
		if(text[i] >= 0x00 && text[i] <= 0x9C)
		{
			str += g_dteTable[text[i] - 0x00];
		}

		else
		{
			CString t;
			t.Format("<%02X>", text[i]);
			str += t;
		}
	}

	return str;
}


int serialise_script(CString iScriptFn, CString iFf6Fn)
{
	CStdioFile inFile;
	if(inFile.Open(iScriptFn, CFile::typeText) == NULL)
	{
		printf(_T("Errors reading %s\n"), iScriptFn);
		return -1;
	}

	CString lScriptFn = iScriptFn;
	CFile outFile;
	if(outFile.Open(iFf6Fn, CFile::modeReadWrite|CFile::typeBinary) == NULL)
	{
		printf(_T("Errors opening %s for writting\n"), iFf6Fn);
		return -1;
	}
	outFile.Seek(SCRIPT_START, CFile::begin);

	//	CStdioFile inFile("D:\\0Data\\myprog\\FF3hack\\utilities\\win32\\EventDisasm\\eventdump.txt", CFile::typeText); //CFile::modeRead);
	//	CFile outFile;
	//	outFile.Open("D:\\0Data\\myprog\\FF3hack\\utilities\\win32\\EventDisasm\\reserialised.bin", CFile::modeCreate|CFile::modeWrite|CFile::typeBinary);

	CString lFileStr;
	char *lStrPtr;
	char *lDebugPtr;
	int lCnt, lCnt2;
	BYTE lConvByte;
	do
	{
		lFileStr.Empty();
		inFile.ReadString(lFileStr);
		lStrPtr = lFileStr.GetBuffer(0);

		if(lFileStr.GetLength()==0)
			break;

		// eliminates PC
		lCnt = 0;
		while(lStrPtr[lCnt] != ':')
			lCnt++;
		lCnt++;

		// eliminates spaces
		while(lStrPtr[lCnt] == ' ')
			lCnt++;

		// process hex
		lCnt2 = 0;
		lConvByte = 0;
		lDebugPtr = &lStrPtr[lCnt];
		while((lStrPtr[lCnt] != '\n') && (lStrPtr[lCnt] != '\0'))
		{
			if(lCnt2%2)
			{
				lConvByte |= ascii2nibble(lStrPtr[lCnt]);
				outFile.Write(&lConvByte, 1);
				lConvByte = 0;
			}
			else
				lConvByte = ascii2nibble(lStrPtr[lCnt])<<4;

			lCnt2++;
			lCnt++;
		}

	} while (lFileStr.GetLength()!=0);

	outFile.Close();
	inFile.Close();

	return 0;
}

BYTE ascii2nibble(BYTE iAsciiChar)
{
	if(iAsciiChar>='a' && iAsciiChar<='f')
	{
		iAsciiChar -= 'a';
		iAsciiChar += 0xA;
	}
	else if(iAsciiChar>='A' && iAsciiChar<='F')
	{
		iAsciiChar -= 'A';
		iAsciiChar += 0xA;
	}
	else if(iAsciiChar>='0' && iAsciiChar<='9')
	{
		iAsciiChar -= '0';
	}
	else
		iAsciiChar = 0xC;

	return(iAsciiChar);
}
